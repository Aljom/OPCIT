$(document).ready(function () {
    $("#sidebar").mCustomScrollbar({
        theme: "minimal",
        scrollInertia: 200,
        mouseWheel:{ preventDefault: true }
    });

    $('#sidebarCollapse, .overlay').on('click', function () {
        $('#sidebar, #content').toggleClass('active');
        $('.collapse.in').toggleClass('in');
        $('a[aria-expanded=true]').attr('aria-expanded', 'false');
        if($("#sidebar").hasClass("active")){
            load_overlay(1);
        }
        else{
            load_overlay(0);
        }   
    });

    function load_overlay(b){
        var width = $(window).width();
        if (width > 768) {

        }
        else{
            if(b>0){
                $('.overlay').fadeIn();
            }
            else{
                $('.overlay').fadeOut();
            }
        }
    }

    $('#accountSubMenu').on('show.bs.collapse', function () {
        $("#acount_toggle").addClass("sidebar-left-line");
        console.log("showing");
    });

    $('#accountSubMenu').on('hidden.bs.collapse', function () {
        $("#acount_toggle").removeClass("sidebar-left-line");
        console.log("closing");
    });

    $('#mngFoldersSubMenu').on('show.bs.collapse', function () {
        $("#mngFolders_toggle").addClass("sidebar-left-line");
        console.log("showing");
    });

    $('#mngFoldersSubMenu').on('hidden.bs.collapse', function () {
        $("#mngFolders_toggle").removeClass("sidebar-left-line");
        console.log("closing");
    });
});