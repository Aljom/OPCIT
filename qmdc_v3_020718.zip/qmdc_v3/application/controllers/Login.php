<?php 
class Login extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		if (isset($_POST['btnLogin'])) {
			$check=$this->Login_model->checkLogin($_POST['username'],$_POST['password']);
			if(count($check)==0)
			{
				$data['error']= "Incorrect Username or Password!";

			}
			else
			{
				header("location:".base_url()."Dashboard");
				//echo "YES!";
				foreach($check as $key)
				{
					$newdata = array('id' => $key->id, 
									'first_name'=>$key->first_name, 
									'last_name'=>$key->last_name, 
									'user_level'=>$key->user_level);
					$this->session->set_userdata($newdata);

					
				}

				
			}
		}

		$data['title'] = "QMDC";
		$this->load->view('login_view', $data);
		//$this->load->view('startup/footer', $data);
	}
}
