<?php

class Add_user extends CI_Controller{

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper(array('form', 'url'));
	}

	public function index(){

		$data['title'] = 'Dashboard';
		$data['department'] = $this->Main_model->getDepartment();
		$this->load->view('admin/header', $data);
		$this->load->view("admin/add_user_view", $data);

		if(isset($_POST['btnAdd'])){
			$values = array('first_name'	=>$this->input->post("first_name",true),
							'middle_name'	=>$this->input->post("middle_name",true),
							'last_name'		=>$this->input->post("last_name",true),
							'address'		=>$this->input->post("address",true),
							'user_level'	=>$this->input->post("user_level",true),
							'department'	=>$this->input->post("department",true),
							'email'			=>$this->input->post("email",true),
							'username'		=>$this->input->post("username",true),
							'password'		=>$this->input->post("password",true));

			$this->Main_model->addNewUsers($values);
			$data['success']= "Successfully Added!";
			$_SESSION['notif'] = "Successfully Added!";
			
			header('Refresh: 0');
		}
		
	}
	public function add_New(){

			$data['title'] = 'Dashboard';
			$data['department'] = $this->Main_model->getDepartment();
			$this->load->view('admin/header', $data);
			$this->load->view("admin/manage_users_view", $data);

		if(isset($_POST['btnAdd'])){
			$values = array('first_name'	=>$this->input->post("first_name",true),
							'middle_name'	=>$this->input->post("middle_name",true),
							'last_name'		=>$this->input->post("last_name",true),
							'address'		=>$this->input->post("address",true),
							'user_level'	=>$this->input->post("user_level",true),
							'department'	=>$this->input->post("department",true),
							'email'			=>$this->input->post("email",true),
							'username'		=>$this->input->post("username",true),
							'password'		=>$this->input->post("password",true));

			$this->Main_model->addNewUsers($values);
			$data['success']= "Successfully Added!";
			
			//header('Refresh: 0');
		}

			

	}

}

?>