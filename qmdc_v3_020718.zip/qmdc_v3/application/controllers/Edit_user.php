<?php

class Edit_user extends CI_Controller{

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper(array('form', 'url'));
	}

	public function index(){

		$data['title'] = 'Dashboard';
		$this->load->view('admin/header', $data);
		$this->load->view("admin/edit_user_view", $data);

	}

}

?>