  <script type="text/javascript">
    document.getElementById("navUsers").setAttribute('class', 'active');
  </script>
 <div id="content">

      <nav class="navbar fixed-top navbar-light bg-light">
        <div class="container-fluid">
          <div class="navbar-header">
            <span class="nav-dash">DASHBOARD</span>
            <button type="button" id="sidebarCollapse" class="navbar-toggler navbar-btn">
              <i class="fa fa-bars" aria-hidden="true"></i>
            </button>
          </div>
        </div>
      </nav>
      <br><br>
  <div class="container-fluid dash-margin-top">
          <div class="row">
            <div class="col-12 top-col">
              <h2 class="main-title">
                <a href="<?php echo base_url() ?>Manage_users" style="color:#2B90D9">
                  Manage Users
                </a>
                <i class="angle right icon" style="font-weight: bold"></i>
                Add User
              </h2>

            </div>

            <hr width="100%">
          </div>
         

          <div class="container-fluid no-padding">
            <div class="row">
              <div class="col-12 no-padding">

                <div class="row">

                  <div class="col-lg-8 col-md-6 col-12">
                     <?php if (isset($_SESSION['notif'])): ?>
                       <div class="alert alert-success alert-dismissible fade show" id="divAlert" style="width: 100%;">
                          <button type="button" class="close" id="close1" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                          <strong><?php echo $_SESSION['notif'] ?></strong>
                      </div>
                      <?php 
                        unset($_SESSION['notif']);
                      endif ?>
                  <!-- card -->
                <div class="card">
                      <div class="card-header cus-card-header" style="background:#fff">
                        <h3 style="font-weight: normal">Profile details</h3>               
                      </div>
                        
                      <div class="card-body">
                        
                        
                        <form action="" method="post">
                
                        <div class="row"> 
                        
                        <div class="col-12">
                          <div class="row">       

                            <div class="ui form col-lg-4">
                              <div class="field">
                                <label>First Name</label>
                                <input type="text" placeholder="First name" name="first_name"  required>
                              </div>
                            </div>

                            <div class="ui form col-lg-4">
                              <div class="field">
                                <label>Middle Name</label>
                                <input type="text" placeholder="Middle name" name="middle_name">
                              </div>
                            </div>

                            <div class="ui form col-lg-4">
                              <div class="field">
                                <label>Last Name</label>
                                <input type="text" placeholder="Last name" name="last_name" required>
                              </div>
                            </div>

                            <div class="ui form col-lg-12">
                              <div class="field">
                                <label>Address</label>
                                <input type="text" placeholder="Address" name="address" required>
                              </div>
                            </div>

                               <div class="ui form col-lg-6">
                                <div class="field">
                                  <label>Department</label>
                                    <select class="ui dropdown" name="department" >
                                       <?php
                                          foreach ($department as $dept){
                                       ?>        
                                        <option value="<?php echo $dept->dept_id ?>"><?php echo $dept->department_name ?></option>
                                      <?php } ?>
                                    </select>
                                  </div>
                                </div>

                                <div class="ui form col-lg-6">
                                  <div class="field">
                                    <label>User Level</label>
                                      <select class="ui dropdown" name="user_level">
                                        <?php
                                          foreach ($userLevel as $dept1){
                                       ?>        
                                        <option value="<?php echo $dept1->user_level_id?>"><?php echo $dept1->name ?></option>
                                      <?php } ?>
                                      </select>
                                    </div>
                                  </div>

                             <div class="ui form col-lg-6">
                              <div class="field">
                                <label>Email Address</label>
                                <input type="email" placeholder="Email Address" name="email"  required>
                              </div>
                            </div>

                            <div class="ui form col-lg-6">
                              <div class="field">
                                <label>Username</label>
                                <input type="text" placeholder="Username" name="username"  required>
                              </div>
                            </div>

                             <div class="ui form col-lg-6">
                              <div class="field">
                                <label>Password</label>
                                <input type="password" placeholder="Password" name="password" id="password" onchange="validatePassword()"  required>
                              </div>
                            </div>

                            <div class="ui form col-lg-6">
                              <div class="field">
                                <label>Confirm Password</label>
                                <input type="password" placeholder="Password" name="password" id="confirm_password" onkeyup="validatePassword()"  required="Password Doesn't Match!">
                              </div>
                            </div>
                            
                          </div>
                          
                          <div class="row">
                            <div class="col-lg-12">
                              <br>
                            <button type="submit" name="btnAdd" class="btn btn-success">Add</button>
                            </div>
                          </div>
                        
                        </div>
                        
                        </div>                
                        
                        </form>
                      </div>
                        
                </div>  
                <!-- end card-body -->
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                  <!-- card -->
                <div class="card">
                      <div class="card-header cus-card-header" style="background:#fff">
                        <h3 style="font-weight: normal">Profile Picture</h3>               
                      </div>
                        
                      <div class="card-body">
                        
                        <form action="#" method="post" enctype="multipart/form-data">
                
                        <div class="row"> 
    
                        <div class="col-12">
                          <center>
                            <img class="ui medium circular image img-fluid profile-pic" src="<?php echo base_url();?>assets/img/user-icon.png">
                          </center>
                        
                          <a class="btn btn-primary upload-new-profile-img-btn" data-toggle="modal" data-target="#changeProfilePicModal">Change profile picture</a>
                        </div>
                        </div>                
                        
                        </form>                   
                        </div>
                </div>  
                <!-- end card-body -->

                </div>
            
                </div>
              
              </div>
            </div>
          </div>
  </div>

</div>
</div>


<!--Scripts-->
  <script type="text/javascript">

    $('.action-btn').dropdown({
        action: 'hide',
        on: 'hover'
    });

    $('select.dropdown').dropdown();

    
    

  function validatePassword(){
    var password = document.getElementById("password")
    var confirm_password = document.getElementById("confirm_password");

    if(password.value != confirm_password.value) {
        confirm_password.setCustomValidity("Passwords Don't Match");
      } else {
        confirm_password.setCustomValidity('');
      }
  }

     $("#close1").click(function(){
      $("#divAlert").hide();
    });



    

  </script>

