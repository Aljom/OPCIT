<meta name="csrf-token" content="XYZ123"> 
 <!-- Dropzone -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/dropzone.css">

<style type="text/css">
  .dropzone .dz-preview .dz-image {
      border-radius: 20px;
      overflow: hidden;
      width: 400px;
      height: 100%;
      position: relative;
      display: block;
      z-index: 10; }
</style>
  <script type="text/javascript">
    document.getElementById("navAccount").setAttribute('class', 'active');
  </script>
 <div id="content">

      <nav class="navbar fixed-top navbar-light bg-light">
        <div class="container-fluid">
          <div class="navbar-header">
            <span class="nav-dash">DASHBOARD</span>
            <button type="button" id="sidebarCollapse" class="navbar-toggler navbar-btn">
              <i class="fa fa-bars" aria-hidden="true"></i>
            </button>
          </div>
        </div>
      </nav>
      <br><br>
  <div class="container-fluid dash-margin-top">
          <div class="row">
            <div class="col-12 top-col">
              <h2 class="main-title">Account Settings</h2>
            </div>

            <hr width="100%">
          </div>
         

          <div class="container-fluid no-padding">
            <div class="row">
              <div class="col-12 no-padding">

                <div class="row">

                  <div class="col-lg-8 col-md-6 col-12">
                  <!-- card -->
                <div class="card">
                      <div class="card-header cus-card-header" style="background:#fff">
                        <h3 style="font-weight: normal">Profile details</h3>               
                      </div>
                        
                      <div class="card-body">
                        
                        
                        <form action="#" method="post">
                
                        <div class="row"> 
                        
                        <div class="col-12">
                          <?php 
                            $userinfo = $this->Login_model->getUserbyID($_SESSION['id']);
                            $firstname = "";
                            foreach ($userinfo as $key) {
                              $first_name       = $key->first_name;
                              $middle_name      = $key->middle_name;
                              $last_name        = $key->last_name;
                              $fullname         = $key->first_name." ".$key->last_name; 
                              $address          = $key->address;
                              $user_level       = $key->user_level;
                              $user_level_name  = $key->name;
                              $email            = $key->email;
                              $department       = $key->department;
                              $department_name  = $key->department_name;
                              $username         = $key->username;
                              $password         = $key->password;
                              $profile_pic      = $key->profile_pic;
                            }

                         ?>
                          
                          <div class="row">       

                            <div class="ui form col-lg-4">
                              <div class="field">
                                <label>First Name</label>
                                <input type="text" placeholder="First name" name="first_name" value="<?php echo $first_name; ?>"  required>
                              </div>
                            </div>

                            <div class="ui form col-lg-4">
                              <div class="field">
                                <label>Middle Name</label>
                                <input type="text" placeholder="Middle name" name="middle_name" value="<?php echo $middle_name; ?>">
                              </div>
                            </div>

                            <div class="ui form col-lg-4">
                              <div class="field">
                                <label>Last Name</label>
                                <input type="text" placeholder="Last name" name="last_name" value="<?php echo $last_name; ?>" required>
                              </div>
                            </div>

                            <div class="ui form col-lg-12">
                              <div class="field">
                                <label>Address</label>
                                <input type="text" placeholder="Address" name="address" value="<?php echo $address; ?>" required>
                              </div>
                            </div>

                               <div class="ui form col-lg-6">
                                <div class="field">
                                  <label>Department</label>

                                    <select name="department" class="ui dropdown" value="<?php echo $department; ?>" >
                                      <option value="<?php echo $department ?>" ><?php echo $department_name; ?></option>
                                       <?php
                                          foreach ($department1 as $dept){
                                       ?>        
                                        <option value="<?php echo $dept->dept_id ?>"><?php echo $dept->department_name ?></option>
                                      <?php } ?>
                                    </select>
                                  </div>
                                </div>

                               <div class="ui form col-lg-6">
                                  <div class="field">
                                    <label>User Level</label>
                                      <select class="ui dropdown" name="user_level" value="<?php echo $user_level?>">
                                        <option value="<?php echo $user_level?>"><?php echo $name?></option>
                                        <?php
                                          foreach ($userLevel as $dept){
                                       ?>        
                                        <option value="<?php echo $dept->user_level_id?>"><?php echo $dept->name ?></option>
                                      <?php } ?>
                                      </select>
                                    </div>
                                  </div>

                             <div class="ui form col-lg-6">
                              <div class="field">
                                <label>Email Address</label>
                                <input type="email" placeholder="Email Address" name="email" value="<?php echo $email; ?>"  required>
                              </div>
                            </div>

                            <div class="ui form col-lg-6">
                              <div class="field">
                                <label>Username</label>
                                <input type="text" placeholder="Username" name="username" value="<?php echo $username; ?>"  required>
                              </div>
                            </div>

                           <!--   <div class="ui form col-lg-6">
                              <div class="field">
                                <label>Password</label>
                                <input type="password" placeholder="Password" name="password" id="password" value="<?php echo $password; ?>" onchange="validatePassword()"  required>
                              </div>
                            </div>

                            <div class="ui form col-lg-6">
                              <div class="field">
                                <label>Confirm Password</label>
                                <input type="password" placeholder="Password" name="password" id="confirm_password" onkeyup="validatePassword()" value="<?php echo $password; ?>"  required="Password Doesn't Match!">
                              </div>
                            </div> -->
                            
                          </div>
                          
                          <div class="row">
                            <div class="col-lg-12">
                              <br>
                            <button type="button" class="btn btn-primary">Edit profile</button>
                            </div>
                          </div>
                        
                        </div>
                        
                        </div>                
                        
                        </form>
                      </div>
                        
                </div>  
                <!-- end card-body -->
                </div>
                
                <div class="col-lg-4 col-md-6 col-12">
                  <!-- card -->
                <div class="card">
                      <div class="card-header cus-card-header" style="background:#fff">
                        <h3 style="font-weight: normal">Profile Picture</h3>               
                      </div>
                        
                      <div class="card-body">
                        
                        <form action="#" method="post" enctype="multipart/form-data">
                
                        <div class="row"> 
    
                        <div class="col-12">
                          <center>
                            <?php 
                            if(file_exists($profile_pic)){?>
                            <img class="ui medium circular image img-fluid profile-pic" src="<?php echo base_url().$profile_pic;?>">
                            <?php
                            }else{?>

                              <img class="ui medium circular image img-fluid profile-pic" src="<?php echo base_url();?>assets/img/user-icon.png">
                              <?php
                            }
                            ?>
                            
                          </center>
                        
                          <a class="btn btn-primary upload-new-profile-img-btn" data-toggle="modal" data-target="#changeProfilePicModal">Change profile picture</a>
                        </div>
                        </div>                
                        
                        </form>                   
                        </div>
                </div>  
                <!-- end card-body -->

                </div>
                  
                </div>
              
              </div>
            </div>
          </div>
  </div>

</div>
</div>
 <!-- Modal -->
  <div class="modal fade" id="changeProfilePicModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title" id="exampleModalLabel">Change Profile Picture</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

           <form id="upload-widget" action="<?php echo base_url();?>profile.php" class="dropzone"  enctype="multipart/form-data"  >
            <div class="dz-message" style="color:#B2B2B2">
              <i class="fa fa-upload" style="font-size:80px;"></i>
             <h3 style="font-weight:normal">Drop image here or click to upload.</h3>
            </div>
            <div class="fallback">
              <center>
                <input name="file_upload" id="file_upload" type="file" /> 
                </center> 
            </div>
          </form>
          <input type="hidden" name="user_id" id="user_id" value="<?php echo $_SESSION['id'];?>">
        
            
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button class="btn btn-primary" id="uploadBtn" name="uploadBtn">Upload</button>
           
        </div>
       
      </div>
    </div>
  </div>

<!--Scripts-->
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/dropzone.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/datatables/dataTables.semanticui.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/bootstrap-colorpicker-master/dist/js/bootstrap-colorpicker.min.js"></script>

  <script type="text/javascript" src="<?php echo base_url();?>assets/js/tablesort.js"></script>
  <script type="text/javascript">
    

    $('table').DataTable({
      searching: true,
      ordering: true
    });

    $('table').tablesort();

    $('.action-btn').dropdown({
        action: 'hide',
        on: 'hover'
    });

    $('.colorpickerinput').colorpicker();

    $('select.dropdown').dropdown();

    Dropzone.options.uploadWidget = {
  //   url: 'upload2.php',
  paramName: 'file',
  //uploadMultiple: true,
  parallelUploads: 5,
  autoProcessQueue: false,
  addRemoveLinks: true,
  dictCancelUpload: 'Uploading File',
  renameFile: true,
  maxFilesize: 1000, // MB
  maxFiles: 1,
  dictDefaultMessage: 'Drag a file here, or click to select one',
  thumbnailWidth:'400',
  thumbnailHeight:'200',
  headers: {
    'x-csrf-token': document.querySelectorAll('meta[name=csrf-token]')[0].getAttributeNode('content').value,
  },
   acceptedFiles: 'image/*',
  init: function() {
    this.on('success', function( file, resp ){
      console.log( file );
      console.log( resp );
    });
     var submitButton = document.querySelector("#uploadBtn")
            myDropzone = this; // closure

        submitButton.addEventListener("click", function(e) {
          
          e.preventDefault();
          e.stopPropagation();
          myDropzone.processQueue(); // Tell Dropzone to process all queued files.

              

          //alert( $("#file_upload").val());
          //location.reload();
        
          
              
        });

        //send all the form data along with the files:
        this.on("sending", function(data, xhr, formData) {
          
          formData.append("user_id", $("#user_id").val());


          swal({
                              type: 'success',
                              title: 'Successfully Uploaded',
                              text: '',
                              confirmButtonClass: "sweetalert-btn"
                          }).then(function(){
                            location.reload();
                          });

        });
        
  
  },

};

  </script>

