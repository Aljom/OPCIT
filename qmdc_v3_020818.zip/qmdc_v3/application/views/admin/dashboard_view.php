 <script type="text/javascript">document.getElementById("navDash").setAttribute('class', 'active');</script>
 <div id="content">

      <nav class="navbar fixed-top navbar-light bg-light">
        <div class="container-fluid">
          <div class="navbar-header">
            <span class="nav-dash">DASHBOARD</span>
            <button type="button" id="sidebarCollapse" class="navbar-toggler navbar-btn">
              <i class="fa fa-bars" aria-hidden="true"></i>
            </button>
          </div>
        </div>
      </nav>
      <br><br>
  <div class="container-fluid dash-margin-top">
        <div class="row">
            <div class="col-12 top-col">
              <h2 class="main-title">Home</h2>
            </div>
            <hr width="100%">

            <div class="col-12 no-padding">
                
              <div class="row">
                
                <div class="col-lg-8">
                  

                </div>

                <div class="col-lg-4">
                  
                   <!-- Latest Uploads Card -->
                <div class="card">
                      <div class="card-header cus-card-header2" style="background:#fff">
                        <h3 style="font-weight: normal">Latest Uploads</h3>               
                      </div>
                        
                      <div class="card-body">
                        
                        <div class="row">
                          
                          <div class="col-12">
                            <div class="row">

                              <div class="col-lg-3">
                                <img class="img-fluid" src="<?php echo base_url(); ?>assets/img/icons/pdf.svg">
                              </div>
                              <div class="col-lg-9 l-up-list-div">
                                <span><b>Sample file.pdf</b></span>
                                <br>
                                <span class="l-up-subtext">Jhon Jefferson Casitas</span>
                                <br>
                                <span class="l-up-subtext">Jan 8, 2018, 8:34 AM</span>
                              </div>

                              <div class="col-lg-3">
                                <img class="img-fluid" src="<?php echo base_url(); ?>assets/img/icons/docx.svg">
                              </div>
                              <div class="col-lg-9 l-up-list-div">
                                <span><b>Sample file.docx</b></span>
                                <br>
                                <span class="l-up-subtext">Jhon Jefferson Casitas</span>
                                <br>
                                <span class="l-up-subtext">Jan 6, 2018, 8:34 AM</span>
                              </div>

                              <div class="col-lg-3">
                                <img class="img-fluid" src="<?php echo base_url(); ?>assets/img/icons/xlsx.svg">
                              </div>
                              <div class="col-lg-9 l-up-list-div">
                                <span><b>Sample file.xlsx</b></span>
                                <br>
                                <span class="l-up-subtext">Jhon Jefferson Casitas</span>
                                <br>
                                <span class="l-up-subtext">Jan 4, 2018, 8:34 AM</span>
                              </div>

                              <div class="col-lg-3">
                                <img class="img-fluid" src="<?php echo base_url(); ?>assets/img/icons/pptx.svg">
                              </div>
                              <div class="col-lg-9 l-up-list-div">
                                <span><b>Sample file.pptx</b></span>
                                <br>
                                <span class="l-up-subtext">Jhon Jefferson Casitas</span>
                                <br>
                                <span class="l-up-subtext">Jan 2, 2018, 8:34 AM</span>
                              </div>

                              <div class="col-lg-12">
                                <button class="btn btn-primary full-width">View more files</button>
                              </div>

                            </div>
                          </div>

                        </div>
                        
                      </div>
                        
                </div>  
                <!-- end card-body -->

                </div>

              </div>

            </div>
        </div>
  </div>

</div>
</div>

