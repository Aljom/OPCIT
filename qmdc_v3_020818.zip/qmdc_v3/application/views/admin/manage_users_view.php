  <script type="text/javascript">
  document.getElementById("navUsers").setAttribute('class', 'active');
</script>
 <div id="content">

      <nav class="navbar fixed-top navbar-light bg-light">
        <div class="container-fluid">
          <div class="navbar-header">
            <span class="nav-dash">DASHBOARD</span>
            <button type="button" id="sidebarCollapse" class="navbar-toggler navbar-btn">
              <i class="fa fa-bars" aria-hidden="true"></i>
            </button>
          </div>
        </div>
      </nav>
      <br><br>
   
              <?php if (isset($_SESSION['notif'])): ?>
                       <div class="alert alert-success alert-dismissible fade show" id="divAlert" style="width: 100%;">
                          <button type="button" class="close" id="close1" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                          <strong><?php echo $_SESSION['notif'] ?></strong>
                      </div>
                      <?php 
                        unset($_SESSION['notif']);
                      endif ?>
  <div class="container-fluid dash-margin-top">
        <div class="row">
            
            <div class="col-lg-6 col-md-6 col-12 top-col">
              <h2 class="main-title">Manage Users</h2>
            </div>
            <div class="col-lg-6 col-md-6 col-12 top-col" align="right">
              <a href="<?php echo base_url() ?>Manage_users/addNew"><button class="ui right labeled icon button blue upload-btn" >
                Add New
                <i class="plus icon"></i>
              </button>
            </a>
            </div>

            <hr width="100%">
          </div>
         

          <div class="container-fluid no-padding">
        <div class="row">
          <div class="col-12 no-padding">
            <table class="ui compact selectable sortable celled blue table" cellspacing="0" width="100%"  style="margin: 0 auto;">
              <thead>
                <tr>
                  <th>No.</th>
                  <th class="">Name</th>
                  <th class="">Role</th>
                  <th class="">Department</th>
                  <th class="">Action</th>
                </tr>
              </thead>
              <tbody>
               <?php 
               $ctr=1;
               foreach ($users as $key): 
                $id =$key->id;
                $fullname = $key->first_name." ".$key->last_name
                ?>
              <tr>
                    <td>
                      <?php echo $ctr ?>
                    </td>
                    <td><?php echo $fullname ?></td>
                    <td><?php echo $key->name ?></td>
                    <td><?php echo $key->department_name ?></td>
                    <td class="action-th">
                      <center>
                        <div class="ui blue action-btn floating dropdown button">
                      <div class="text">Action</div>
                      <i class="dropdown icon" style="margin-left: 20px;margin-right: 0px;"></i>
                      <div class="menu">
                        <a href="Manage_users/editUser/<?php echo $key->id?>" class="item">
                        <i class="edit icon"></i> Edit</a>
                        <div class="item" data-target="#deleteUser<?php echo $key->id?>" data-toggle="modal"><i class="delete icon" ></i> Remove</div>
                      </div>
                    </div>
                  </center>
                    </td>
                </tr>
                

                <!-- DeleteModal -->
  <div class="modal fade" id="deleteUser<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title" id="exampleModalLabel">Delete User</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <form method="POST" action="">
            <div class="ui form">
              <div class="field">
                <label></label>
               <div class="text">Are you Sure you want to remove <b><?php echo $fullname;?></b>?</div>
               <input type="hidden" name="user_id" value="<?php echo $key->id?>">
              </div>
            </div>      
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
          <button type="submit"  class="btn btn-primary" name="deleteUser">Yes</button>
           </form>
        </div>
       
      </div>
    </div>
  </div>
              <?php $ctr++; endforeach ?>
            </tbody>
            </table>
          </div>
        </div>
      </div>
  </div>

</div>
</div>


<!--Scripts-->
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/datatables/dataTables.semanticui.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/bootstrap-colorpicker-master/dist/js/bootstrap-colorpicker.min.js"></script>

  <script type="text/javascript" src="<?php echo base_url();?>assets/js/tablesort.js"></script>
  <script type="text/javascript">
    

    $('table').DataTable({
      searching: true,
      ordering: true
    });

    $('table').tablesort();

    $('.action-btn').dropdown({
        action: 'hide',
        on: 'hover'
    });

    $('.colorpickerinput').colorpicker();

    $('select.dropdown').dropdown();


    $("#close1").click(function(){
      $("#divAlert").hide();
    });


  </script>

