<?php

class Manage_user_level extends CI_Controller{

	public function index(){

		$data['title'] = 'Manage User Level';
		$data['user_level'] = $this->Main_model->getUserLevel();
		$this->load->view('admin/header', $data);
		$this->load->view("admin/manage_user_level_view", $data);

		if(isset($_POST['btnAdd'])){
			$values = array('name'			=>$this->input->post("name",true),
							'description'	=>$this->input->post("description",true));

			$this->Main_model->addUserLevel($values);

			$_SESSION['notif'] = "Successfully Added!";
			header("Refresh: 0");
		}

		if(isset($_POST['deleteBtn'])){
			$id = $this->input->post("user_id",true);

			$this->Main_model->deleteUserLevel($id);
			$_SESSION['notif'] = "Successfully Removed!";
			header("Refresh: 0");
		}

		if(isset($_POST['btnSave'])){
			$id = $this->input->post("user_id2",true);

			$values = array('name'			=>$this->input->post("name2",true),
							'description'	=>$this->input->post("description2",true));

			$this->Main_model->updateUserLevel($id,$values);
			$_SESSION['notif'] = "Successfully Updated!";
			header("Refresh: 0");
		}

	}

}

?>