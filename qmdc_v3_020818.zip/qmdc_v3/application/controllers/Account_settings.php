<?php

class Account_settings extends CI_Controller{

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		$id = $_SESSION['id'];
		$data['title'] = 'Account Settings';
		$data['userinfo'] = $this->Login_model->getUserbyID($id);
		$data['userLevel'] = $this->Main_model->getUserLevel();
		$data['department1'] = $this->Main_model->getDepartment();
		$this->load->view('admin/header', $data);
		$this->load->view("admin/account_settings_view", $data);

	}

}

?>