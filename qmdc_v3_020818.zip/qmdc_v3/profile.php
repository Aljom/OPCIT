<?php
$conn = mysqli_connect("localhost","root","","qmdc");
$ut="utf8";
mysqli_set_charset($conn,$ut);

if(!$conn){
	echo mysqli_error();
}

$ds          = DIRECTORY_SEPARATOR;  //1
 
//$storeFolder = 'UPLOADS';   //2
 $user_id = mysqli_escape_string($conn,$_POST['user_id']);
if (!empty($_FILES)) {
     
    $tempFile = $_FILES['file']['tmp_name'];          //3             
      
    // $targetPath = dirname( __FILE__ ) . $ds. $storeFolder . $ds;  //4
     
    // $targetFile =  $targetPath. $_FILES['file']['name'];  //5

    $MY_FILE_NAME = $_FILES["file"]["name"];


    	$storeFolder = 'Profile_pics';

    	$targetPath =  $storeFolder . $ds;

    	$targetFile =  $targetPath. $_FILES['file']['name'];

    	 if(move_uploaded_file($tempFile,$targetFile)) {
	    	$sql = "UPDATE user_login SET profile_pic = '".$targetFile."' WHERE id = '".$user_id."' ";
            $query = mysqli_query($conn,$sql);
    	}

    }

// function InsertingData($owner,$purpose,$MY_FILE,$targetFile){

// 		$sql = "INSERT INTO tbl_file_upload (owner,purpose,file_ext,file_name) VALUES('".$owner."','".$purpose."','".$MY_FILE."','".$targetFile."')";
//     	$query = mysqli_query($conn,$sql);

// }
?>   