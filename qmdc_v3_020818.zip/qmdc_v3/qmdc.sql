-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 08, 2018 at 10:54 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qmdc`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectAllUser` ()  SQL SECURITY INVOKER
SELECT * FROM user_login$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

CREATE TABLE `tbl_department` (
  `dept_id` int(5) NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_department`
--

INSERT INTO `tbl_department` (`dept_id`, `department_name`, `description`) VALUES
(1, 'IT Department', 'Can add, edit, delete everything'),
(2, 'CBAT Department', 'Can search, add, edit, delete files only.'),
(3, 'CCS Department', 'College of Computer Science'),
(5, 'Generals Department', 'Administrators');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_file_upload`
--

CREATE TABLE `tbl_file_upload` (
  `id` int(5) NOT NULL,
  `owner` varchar(100) NOT NULL,
  `purpose` varchar(200) NOT NULL,
  `department` varchar(100) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `file_ext` varchar(100) NOT NULL,
  `file_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_file_upload`
--

INSERT INTO `tbl_file_upload` (`id`, `owner`, `purpose`, `department`, `date_added`, `file_ext`, `file_name`) VALUES
(129, 'asdad', 'asdad', 'Generals Department', '2018-02-07 07:45:14', 'png', 'chipahhbahgdjjop.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_level`
--

CREATE TABLE `tbl_user_level` (
  `user_level_id` int(5) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_level`
--

INSERT INTO `tbl_user_level` (`user_level_id`, `name`, `description`) VALUES
(1, 'Administrator', 'DO EVERYTHING'),
(2, 'CBAT', 'Can Add, Remove and Search Files. '),
(4, 'Guest', 'Can Upload and Download, Search Files'),
(5, 'Staff', 'Monitoring');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(5) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `department` int(3) NOT NULL,
  `user_level` int(3) DEFAULT NULL COMMENT '1 = admin/ director , 2 = cbat , 3 = staff, 4 = accreditor',
  `profile_pic` varchar(200) NOT NULL,
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `first_name`, `middle_name`, `last_name`, `address`, `email`, `username`, `password`, `department`, `user_level`, `profile_pic`, `createdDate`) VALUES
(1, 'Jomarie', 'Alarcon', 'Lumactod', 'Taguig City', 'jlumactod1@gmail.com', 'jlumactod', '123', 1, 1, 'Profile_pics/ccs.png', '2018-02-08 09:37:54'),
(16, 'Jomiel', 'Palma', 'Andrade', 'Pateros City', 'jomielandrade@gmail.com', 'jomiel', 'dasd', 2, 2, '', '2018-02-07 07:34:19'),
(17, 'Ron', 'Baba', 'Balbin', 'asdad', 'test1@test.com', 'qwe', '123', 2, 5, '', '2018-02-07 07:34:48'),
(45, 'Manuel', 'Morfe', 'Quiambao', 'Makati City', 'jaycute@gmail.com', 'jay', '123', 1, 1, 'Profile_pics/05.FOOD-min.jpg', '2018-02-08 09:33:07'),
(56, 'Jeff ', 'Orca', 'Casitas', 'Laguna', 'jaycasitas@gmail.com', 'jeff', '123', 2, 1, 'Profile_pics/62948e6d2b9080bc383feeafceaf4aa5f2de3627.png', '2018-02-08 09:40:13'),
(57, 'Hernan', 'Sigabor', 'Alar', 'Target', 'halar@gmail.com', 'halar', '123', 3, 4, '', '2018-02-07 07:34:24'),
(58, 'Rex', 'Patootie', 'Cortez', 'Pateros City', 'rex@gmail.com', 'rex', '123', 3, 5, '', '2018-02-07 07:34:29'),
(60, 'Gilbert', '', 'Marfil', 'Makati City', 'gilbert@gmail.com', 'gilbert', '123', 3, 4, 'Profile_pics/2936ae5ee01c1b77130875b7f3a2d74d8a7f6370.png', '2018-02-08 09:41:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_department`
--
ALTER TABLE `tbl_department`
  ADD PRIMARY KEY (`dept_id`);

--
-- Indexes for table `tbl_file_upload`
--
ALTER TABLE `tbl_file_upload`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_level`
--
ALTER TABLE `tbl_user_level`
  ADD PRIMARY KEY (`user_level_id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_department`
--
ALTER TABLE `tbl_department`
  MODIFY `dept_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_file_upload`
--
ALTER TABLE `tbl_file_upload`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;
--
-- AUTO_INCREMENT for table `tbl_user_level`
--
ALTER TABLE `tbl_user_level`
  MODIFY `user_level_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
