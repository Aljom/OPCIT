
<div id="listing" style="width:98%; margin:auto; border:#333333 solid 1px;  border-bottom-width:2px; border-right-width:2px; padding:5px; background-color:#FFFFFF;  ">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
  			<tr>
    			<td height="40" colspan="8" align="center" bgcolor="#FFFFFF" style="font-size:16px"  ><strong>Monthly Report</strong></td>
		  	</tr>
  			<tr bgcolor="#ffffff" valign="bottom" style="color:#333333 ">
    			<th height="1" colspan="8" align="left" ><div style="border-bottom:#333333 2px solid"></div></th>
		  	</tr>
	</table>
	<br><br><br>
	<?php 
	
	$year = date('Y');
	while($year>2015){
		$optYear = "<option value'{$year}'>{$year}</option>";
		$year = $year-1;
	}
	$Month = date('m');
	?>
	<form id="Form1">
		<input type="Hidden" id="Process" name="Process" value="report">
		
		Report type: <select id="slcReporttype" name="slcReporttype" style="width:100px;">
						<!--option value=""></option-->
						<option value="r3text">R3 Textfile</option>
					 </select> &nbsp;&nbsp;
		<span id="sbr">
			SBR No: <input type="Text" id="txtSBRNo" name="txtSBRNo" style="width:80px;">&nbsp;&nbsp;
			SBR Date: <input name='txtSBRDate' type='text' id="txtSBRDate"  onclick="displayDatePicker('txtSBRDate', false, 'ymd', '-');" style="width:85px;" placeholder='YYYY-MM-DD'/>&nbsp;&nbsp;
			
		</span>&nbsp;&nbsp;
		
		Date : 	<select id="slcYear" name="slcYear" style="width:60px;"><?php echo $optYear;?></select>
				<select id="slcMonth" name="slcMonth" style="width:100px;">
					<option value="01" <?php if($Month=='01'){ echo "selected"; }?>>January</option>
					<option value="02" <?php if($Month=='02'){ echo "selected"; }?>>February</option>
					<option value="03" <?php if($Month=='03'){ echo "selected"; }?>>March</option>
					<option value="04" <?php if($Month=='04'){ echo "selected"; }?>>April</option>
					<option value="05" <?php if($Month=='05'){ echo "selected"; }?>>May</option>
					<option value="06" <?php if($Month=='06'){ echo "selected"; }?>>June</option>
					<option value="07" <?php if($Month=='07'){ echo "selected"; }?>>July</option>
					<option value="08" <?php if($Month=='08'){ echo "selected"; }?>>August</option>
					<option value="09" <?php if($Month=='09'){ echo "selected"; }?>>September</option>
					<option value="10" <?php if($Month=='10'){ echo "selected"; }?>>October</option>
					<option value="11" <?php if($Month=='11'){ echo "selected"; }?>>November</option>
					<option value="12" <?php if($Month=='12'){ echo "selected"; }?>>December</option>
				</select>
				
				<input type="Button" id="btnGenerate" name="btnGenerate" value="Generate">
				&nbsp;<span id="sssfile"></span>
				
	</form>	
	<div id="result"></div>
	<br><br><br>
</div>




