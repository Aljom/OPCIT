-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 15, 2016 at 08:19 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `timekeeping`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_bio`
--

CREATE TABLE `tbl_tk_bio` (
  `id` int(11) NOT NULL,
  `temp_id` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `bio_id` int(11) NOT NULL DEFAULT '0',
  `ip_address` varchar(15) NOT NULL DEFAULT '-',
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_bio_setup`
--

CREATE TABLE `tbl_tk_bio_setup` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(20) DEFAULT NULL,
  `port_no` int(11) DEFAULT NULL,
  `mode_type` varchar(10) DEFAULT '-',
  `device_location` varchar(20) DEFAULT NULL,
  `office_location` varchar(20) DEFAULT NULL,
  `device_info` varchar(25) NOT NULL,
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_change_schedule`
--

CREATE TABLE `tbl_tk_change_schedule` (
  `id` int(11) NOT NULL,
  `user_id` varchar(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `no_of_days` int(11) NOT NULL,
  `change_type` varchar(255) NOT NULL,
  `change_time` varchar(255) NOT NULL,
  `dates` varchar(255) NOT NULL,
  `include_schedule` varchar(255) NOT NULL,
  `time_in` varchar(255) NOT NULL,
  `time_out` varchar(255) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '''0=For Approval'', ''1=Approved'', ''2=Disapproved''',
  `remarks` varchar(100) DEFAULT NULL,
  `approved_by_id` int(11) DEFAULT '0',
  `approved_by` varchar(150) DEFAULT '-',
  `approved_date` datetime DEFAULT '0000-00-00 00:00:00',
  `approved_code` varchar(25) DEFAULT '-',
  `approved_link` varchar(255) NOT NULL DEFAULT '-',
  `approved_source` varchar(15) DEFAULT '' COMMENT 'web/email/sms',
  `request_source` varchar(15) DEFAULT 'web' COMMENT 'web/sms',
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `approver_list` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_leave`
--

CREATE TABLE `tbl_tk_leave` (
  `id` int(11) NOT NULL,
  `employee_uid` int(11) NOT NULL DEFAULT '0',
  `employee_id` varchar(11) DEFAULT '-',
  `fullname` varchar(255) NOT NULL DEFAULT '-',
  `leave_type` varchar(20) NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `no_days` float NOT NULL DEFAULT '0.5',
  `resume_date` date DEFAULT NULL,
  `d_array` text NOT NULL,
  `h_array` text NOT NULL,
  `p_array` text NOT NULL,
  `leave_reason` varchar(255) NOT NULL DEFAULT '-',
  `with_pay` float(3,1) NOT NULL DEFAULT '0.0',
  `without_pay` float(3,1) NOT NULL DEFAULT '0.0',
  `status` int(3) NOT NULL DEFAULT '0' COMMENT '''0=For Approval'', ''1=Approved'', ''2=Disapproved''',
  `remarks` varchar(100) DEFAULT NULL,
  `date_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` datetime DEFAULT '0000-00-00 00:00:00',
  `approved_by_id` int(11) NOT NULL DEFAULT '0',
  `approved_by` varchar(150) NOT NULL DEFAULT '-',
  `approved_date` datetime DEFAULT '0000-00-00 00:00:00',
  `approved_code` varchar(255) DEFAULT '-',
  `approved_link` varchar(255) NOT NULL DEFAULT '-',
  `approved_source` varchar(15) DEFAULT 'web' COMMENT 'web/email/sms',
  `request_source` varchar(15) DEFAULT 'web' COMMENT 'web/sms',
  `special_leave` varchar(20) DEFAULT NULL,
  `attachment` text,
  `file_id` text,
  `approver_list` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_logs`
--

CREATE TABLE `tbl_tk_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `module` varchar(50) NOT NULL,
  `action` enum('insert','update','delete','upload','approve','disapprove','adapt','compute','export') NOT NULL,
  `type` enum('form','upload','email') NOT NULL DEFAULT 'form',
  `details` text NOT NULL,
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_overtime`
--

CREATE TABLE `tbl_tk_overtime` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `employee_id` varchar(11) DEFAULT NULL,
  `fullname` varchar(255) NOT NULL DEFAULT '-',
  `include_time` varchar(255) NOT NULL,
  `overtime_date_from` date NOT NULL,
  `overtime_date_to` date NOT NULL,
  `overtime_date` varchar(255) DEFAULT NULL,
  `overtime_from` varchar(255) DEFAULT NULL,
  `overtime_to` varchar(255) DEFAULT NULL,
  `overtime_break` varchar(255) NOT NULL,
  `overtime_hours` varchar(5) DEFAULT NULL,
  `no_of_days` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `overtime_for` enum('Pay','Offset') NOT NULL DEFAULT 'Pay',
  `status` int(3) NOT NULL DEFAULT '0' COMMENT '''0=For Approval'', ''1=Approved'', ''2=Disapproved''',
  `remarks` varchar(100) NOT NULL DEFAULT '-',
  `date_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` datetime DEFAULT '0000-00-00 00:00:00',
  `approved_by_id` int(11) DEFAULT '0',
  `approved_by` varchar(150) DEFAULT '-',
  `approved_date` datetime DEFAULT '0000-00-00 00:00:00',
  `approved_code` varchar(255) NOT NULL DEFAULT '-',
  `approved_link` varchar(255) NOT NULL DEFAULT '-',
  `approved_source` varchar(15) DEFAULT 'web' COMMENT 'web/email/sms',
  `request_source` varchar(15) DEFAULT 'web' COMMENT 'web/sms',
  `approver_list` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_schedule_lookup`
--

CREATE TABLE `tbl_tk_schedule_lookup` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(150) NOT NULL DEFAULT '-',
  `date` date NOT NULL,
  `dayname` varchar(10) DEFAULT NULL,
  `prefix` varchar(10) DEFAULT NULL,
  `schedule_code` varchar(25) NOT NULL,
  `schedule_status` varchar(25) NOT NULL,
  `schedule_in` varchar(5) DEFAULT NULL,
  `schedule_out` varchar(5) DEFAULT NULL,
  `in` varchar(5) DEFAULT NULL,
  `out` varchar(5) DEFAULT NULL,
  `hours` varchar(7) NOT NULL DEFAULT '0',
  `remarks` text,
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_tk_in_out_raw`
--

CREATE TABLE `tb_tk_in_out_raw` (
  `id` int(11) NOT NULL,
  `count` int(11) DEFAULT NULL,
  `user_id` varchar(45) DEFAULT NULL,
  `verifyMode` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `Date` varchar(45) DEFAULT NULL,
  `time` varchar(45) DEFAULT NULL,
  `timedate` datetime DEFAULT NULL,
  `ip_address` varchar(15) NOT NULL,
  `ip_remote` varchar(15) DEFAULT '-',
  `mode_type` varchar(10) NOT NULL,
  `workCode` varchar(45) DEFAULT NULL,
  `reserved` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_tk_bio`
--
ALTER TABLE `tbl_tk_bio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_bio_setup`
--
ALTER TABLE `tbl_tk_bio_setup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_change_schedule`
--
ALTER TABLE `tbl_tk_change_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_leave`
--
ALTER TABLE `tbl_tk_leave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_logs`
--
ALTER TABLE `tbl_tk_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_overtime`
--
ALTER TABLE `tbl_tk_overtime`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_schedule_lookup`
--
ALTER TABLE `tbl_tk_schedule_lookup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_tk_in_out_raw`
--
ALTER TABLE `tb_tk_in_out_raw`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_tk_bio`
--
ALTER TABLE `tbl_tk_bio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_bio_setup`
--
ALTER TABLE `tbl_tk_bio_setup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_change_schedule`
--
ALTER TABLE `tbl_tk_change_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_leave`
--
ALTER TABLE `tbl_tk_leave`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_logs`
--
ALTER TABLE `tbl_tk_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_overtime`
--
ALTER TABLE `tbl_tk_overtime`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_schedule_lookup`
--
ALTER TABLE `tbl_tk_schedule_lookup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tb_tk_in_out_raw`
--
ALTER TABLE `tb_tk_in_out_raw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
