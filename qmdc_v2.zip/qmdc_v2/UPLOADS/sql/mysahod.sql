-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 22, 2016 at 02:42 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mysahod`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hris_employee_accountinfo`
--

CREATE TABLE `tbl_hris_employee_accountinfo` (
  `account_no` varchar(25) DEFAULT NULL,
  `sss` varchar(50) DEFAULT '-',
  `philhealth` varchar(50) DEFAULT '-',
  `pagibig` varchar(50) DEFAULT '-',
  `tin` varchar(50) DEFAULT '-',
  `sl` double NOT NULL DEFAULT '0',
  `el` double NOT NULL DEFAULT '0',
  `vl` double NOT NULL DEFAULT '0',
  `hired_date` date DEFAULT NULL,
  `reg_date` date DEFAULT NULL,
  `is_resigned` tinyint(4) DEFAULT '0',
  `resigned_date` date DEFAULT NULL,
  `reason_resigned` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `exempt_status` enum('1','0') NOT NULL DEFAULT '0',
  `exempt_sss` tinyint(1) NOT NULL DEFAULT '0',
  `exempt_philhealth` tinyint(1) NOT NULL DEFAULT '0',
  `exempt_pagibig` tinyint(1) NOT NULL DEFAULT '0',
  `exempt_tax` tinyint(1) NOT NULL DEFAULT '0',
  `approver_id` int(11) NOT NULL DEFAULT '0',
  `picture` text,
  `schedule` int(11) NOT NULL DEFAULT '0',
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hris_employee_dependent`
--

CREATE TABLE `tbl_hris_employee_dependent` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `sss` tinyint(1) NOT NULL DEFAULT '0',
  `philhealth` tinyint(1) NOT NULL DEFAULT '0',
  `pagibig` tinyint(1) NOT NULL DEFAULT '0',
  `tax` tinyint(1) NOT NULL DEFAULT '0',
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hris_employee_education`
--

CREATE TABLE `tbl_hris_employee_education` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT '0',
  `school_name` varchar(255) DEFAULT NULL,
  `achievement` varchar(255) DEFAULT NULL,
  `degree` varchar(255) DEFAULT NULL,
  `education_type` int(11) DEFAULT NULL,
  `year_from` int(11) NOT NULL,
  `year_to` int(11) NOT NULL,
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hris_employee_info`
--

CREATE TABLE `tbl_hris_employee_info` (
  `bio_id` varchar(255) NOT NULL,
  `id` int(11) NOT NULL,
  `user_level` int(11) NOT NULL DEFAULT '0',
  `employee_id` varchar(11) DEFAULT NULL,
  `last_name` varchar(25) DEFAULT '-',
  `middle_name` varchar(25) DEFAULT '-',
  `middle_initial` varchar(25) NOT NULL,
  `first_name` varchar(50) DEFAULT '-',
  `nick_name` varchar(50) NOT NULL,
  `suffix_name` varchar(50) NOT NULL,
  `gender` varchar(6) DEFAULT 'Male',
  `civil_status` int(11) NOT NULL DEFAULT '0',
  `birth_date` date DEFAULT NULL,
  `nationality` varchar(25) DEFAULT NULL,
  `religion` varchar(25) DEFAULT NULL,
  `address` varchar(255) DEFAULT '-',
  `town` varchar(20) DEFAULT '-',
  `city` varchar(20) DEFAULT '-',
  `province` varchar(20) DEFAULT '-',
  `home_no` varchar(20) DEFAULT '-',
  `mobile_no` varchar(20) DEFAULT '-',
  `email_address` varchar(50) DEFAULT '-',
  `department_id` int(11) DEFAULT NULL,
  `department` varchar(45) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  `job_position_id` int(11) DEFAULT NULL,
  `job_position` varchar(45) DEFAULT NULL,
  `corporate_rank_id` int(11) DEFAULT NULL,
  `corporate_rank` varchar(45) DEFAULT NULL,
  `job_status_id` int(11) DEFAULT NULL,
  `job_status` varchar(45) DEFAULT NULL,
  `job_grade` tinyint(4) DEFAULT '0',
  `payroll_category` int(11) NOT NULL DEFAULT '1',
  `payroll_setup` enum('monthly','semi-monthly','daily') NOT NULL DEFAULT 'semi-monthly',
  `salary_rate` float NOT NULL DEFAULT '0',
  `ecola` float(7,2) NOT NULL DEFAULT '0.00',
  `pagibig_additional` decimal(18,2) NOT NULL DEFAULT '0.00',
  `tax_exemption` varchar(50) NOT NULL DEFAULT 'Z',
  `hired_date` date DEFAULT NULL,
  `reg_date` date DEFAULT NULL,
  `is_resigned` tinyint(4) DEFAULT '0',
  `resigned_date` date DEFAULT NULL,
  `reason_resigned` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `exempt_status` enum('1','0') NOT NULL DEFAULT '0',
  `exempt_sss` tinyint(1) NOT NULL DEFAULT '0',
  `exempt_philhealth` tinyint(1) NOT NULL DEFAULT '0',
  `exempt_pagibig` tinyint(1) NOT NULL DEFAULT '0',
  `exempt_tax` tinyint(1) NOT NULL DEFAULT '0',
  `approver_id` int(11) NOT NULL DEFAULT '0',
  `picture` text,
  `schedule` int(11) NOT NULL DEFAULT '0',
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hris_employee_movement`
--

CREATE TABLE `tbl_hris_employee_movement` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '-',
  `reference_date` date NOT NULL,
  `lookup_uid` int(11) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `l_code` varchar(50) NOT NULL,
  `l_description` varchar(50) NOT NULL,
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_hris_employee_movement`
--

INSERT INTO `tbl_hris_employee_movement` (`id`, `user_id`, `name`, `reference_date`, `lookup_uid`, `l_name`, `l_code`, `l_description`, `date_updated`, `date_created`) VALUES
(1, 4, 'PERKINS, MARY GENE TAMIKO F', '2016-08-05', 243, 'PEZA Section', 'MANAGEMENT', 'MANAGEMENT', '2016-08-05 14:54:20', '2016-08-05 06:54:20'),
(2, 116, 'BAUTISTA, MARIE CLARISSE S', '2015-10-01', 32, 'Job Position', 'Senior Analyst', 'Senior Analyst', '2016-08-12 14:13:05', '2016-08-12 06:13:05'),
(3, 116, 'BAUTISTA, MARIE CLARISSE S', '2015-10-01', 100, 'Corporate Rank', 'SR STAFF', 'Senior Staff', '2016-08-12 14:13:20', '2016-08-12 06:13:20'),
(4, 53, 'DAYAG, MARIA EIMEE ANN REA D', '2016-06-16', 163, 'Employee Category', 'REG', 'Regular', '2016-08-16 17:13:33', '2016-08-16 09:13:35'),
(5, 67, 'LOPEZ , LARRY E', '2016-05-19', 163, 'Employee Category', 'REG', 'Regular', '2016-08-16 19:09:04', '2016-08-16 11:09:05'),
(6, 67, 'LOPEZ , LARRY E', '2016-05-19', 163, 'Employee Category', 'REG', 'Regular', '2016-08-16 19:09:06', '2016-08-16 11:09:07'),
(7, 67, 'LOPEZ , LARRY E', '0000-00-00', 164, 'Employee Category', 'PRO', 'Probationary', '2016-08-16 19:09:24', '2016-08-16 11:09:25'),
(8, 54, 'SANTOS , IMELDA D', '2016-04-01', 50, 'Job Position', 'Assistant Operation Manager', 'Assistant Operation Manager', '2016-08-17 13:25:08', '2016-08-17 05:25:09'),
(9, 54, 'SANTOS , IMELDA D', '0000-00-00', 99, 'Corporate Rank', 'ASSIST MNGR', 'Assistant Manager', '2016-08-17 13:25:44', '2016-08-17 05:25:45'),
(10, 54, 'SANTOS , IMELDA D', '0000-00-00', 222, 'MOLIPS PH', 'HRADMIN', 'HR & ADMINISTRATION', '2016-08-17 13:26:57', '2016-08-17 05:26:58'),
(11, 54, 'SANTOS , IMELDA D', '0000-00-00', 25, 'Department', 'OPE', 'Operations', '2016-08-17 13:27:34', '2016-08-17 05:27:35'),
(12, 54, 'SANTOS , IMELDA D', '0000-00-00', 163, 'Employee Category', 'REG', 'Regular', '2016-08-17 13:27:44', '2016-08-17 05:27:45'),
(13, 54, 'SANTOS , IMELDA D', '0000-00-00', 238, 'MOL ASIA', 'SUPPORT', 'SUPPORT ', '2016-08-17 13:30:02', '2016-08-17 05:30:03'),
(14, 0, '', '0000-00-00', 0, '', '', '', '2016-08-17 13:30:04', '2016-08-17 05:30:05'),
(15, 14, 'SANTIAGO, CAMILLE ANN  V', '0000-00-00', 237, 'MOL ASIA', 'PHILS', 'PHILS', '2016-08-17 13:58:34', '2016-08-17 05:58:35'),
(16, 30, 'SANGALANG, PAUL GERALD M', '0000-00-00', 235, 'MOL ASIA', 'LINER', 'LINER', '2016-08-19 09:49:24', '2016-08-19 01:49:25'),
(17, 30, 'SANGALANG, PAUL GERALD M', '0000-00-00', 272, 'MOLIPS PH', 'VGM', 'VGM', '2016-08-19 09:49:51', '2016-08-19 01:49:52'),
(18, 95, 'DISPO, JOHN HENLEY A', '0000-00-00', 25, 'Department', 'OPE', 'Operations', '2016-08-19 09:58:31', '2016-08-19 01:58:32'),
(19, 47, 'OMBROG, LOUIE M', '2016-08-15', 163, 'Employee Category', 'REG', 'Regular', '2016-08-23 09:34:41', '2016-08-23 01:34:42'),
(20, 163, 'DELOS REYES, MARJORIE M', '0000-00-00', 164, 'Employee Category', 'PRO', 'Probationary', '2016-08-23 10:12:16', '2016-08-23 02:12:17'),
(21, 3, 'RIVERO, MARIA RENEE M', '0000-00-00', 48, 'Job Position', 'Manager', 'Manager', '2016-08-24 09:15:16', '2016-08-24 01:15:17'),
(22, 3, 'RIVERO, MARIA RENEE M', '0000-00-00', 97, 'Corporate Rank', 'GEN MNGR', 'Manager', '2016-08-24 09:15:40', '2016-08-24 01:15:41'),
(23, 0, '', '0000-00-00', 0, '', '', '', '2016-08-24 09:15:44', '2016-08-24 01:15:45'),
(29, 163, 'DELOS REYES, MARJORIE M', '0000-00-00', 25, 'Department', 'OPE', 'Operations', '2016-08-25 15:21:08', '2016-08-25 07:21:09'),
(30, 86, 'GOITI , AIZA T', '0000-00-00', 98, 'Corporate Rank', 'JR SPRVR', 'Junior Supervisor', '2016-08-25 15:42:22', '2016-08-25 07:42:23'),
(31, 50, 'CALADO, MA. CRISELDA  T', '0000-00-00', 32, 'Job Position', 'Senior Analyst', 'Senior Analyst', '2016-08-25 15:52:41', '2016-08-25 07:52:43'),
(32, 50, 'CALADO, MA. CRISELDA  T', '0000-00-00', 100, 'Corporate Rank', 'SR STAFF', 'Senior Staff', '2016-08-25 15:52:52', '2016-08-25 07:52:53'),
(33, 50, 'CALADO, MA. CRISELDA  T', '2016-08-24', 163, 'Employee Category', 'REG', 'Regular', '2016-08-25 15:56:45', '2016-08-25 07:56:46'),
(34, 163, 'DELOS REYES, MARJORIE M', '2016-08-25', 226, 'MOLIPS PH', 'LYM', 'LYM', '2016-08-25 16:38:39', '2016-08-25 08:38:40'),
(35, 2, 'PESARILLO, ROSANIDA P', '0000-00-00', 97, 'Corporate Rank', 'GEN MNGR', 'Manager', '2016-08-25 18:01:20', '2016-08-25 10:01:21'),
(36, 2, 'PESARILLO, ROSANIDA P', '2016-04-01', 103, 'Corporate Rank', 'PRES', 'President', '2016-08-25 18:01:36', '2016-08-25 10:01:37'),
(37, 42, 'BARBIN , JELYN A', '0000-00-00', 23, 'Department', 'FIN', 'Finance', '2016-08-30 15:54:45', '2016-08-30 07:54:46'),
(38, 53, 'DAYAG, MARIA EIMEE ANN REA D', '0000-00-00', 163, 'Employee Category', 'REG', 'Regular', '2016-08-30 16:00:44', '2016-08-30 08:00:45'),
(39, 53, 'DAYAG, MARIA EIMEE ANN REA D', '0000-00-00', 24, 'Department', 'HRA', 'HR & Administration', '2016-08-30 16:00:54', '2016-08-30 08:00:55'),
(40, 90, 'LAMADRID, CHRIS ANTHONY  A', '0000-00-00', 22, 'Department', 'MIS', 'MIS', '2016-08-30 16:02:12', '2016-08-30 08:02:13'),
(41, 0, '', '0000-00-00', 0, '', '', '', '2016-08-30 16:02:19', '2016-08-30 08:02:20'),
(42, 67, 'LOPEZ , LARRY E', '0000-00-00', 25, 'Department', 'OPE', 'Operations', '2016-08-30 16:06:16', '2016-08-30 08:06:17'),
(43, 67, 'LOPEZ , LARRY E', '0000-00-00', 50, 'Job Position', 'Assistant Operation Manager', 'Assistant Operation Manager', '2016-08-30 16:06:35', '2016-08-30 08:06:36'),
(44, 67, 'LOPEZ , LARRY E', '0000-00-00', 99, 'Corporate Rank', 'ASSIST MNGR', 'Assistant Manager', '2016-08-30 16:06:48', '2016-08-30 08:06:49'),
(45, 70, 'MASALUNGA , ANNA P', '0000-00-00', 24, 'Department', 'HRA', 'HR & Administration', '2016-08-30 16:07:53', '2016-08-30 08:07:54'),
(46, 70, 'MASALUNGA , ANNA P', '0000-00-00', 62, 'Job Position', 'Team Leader', 'Team Leader', '2016-08-30 16:08:13', '2016-08-30 08:08:14'),
(47, 70, 'MASALUNGA , ANNA P', '0000-00-00', 42, 'Job Position', 'HR ASSISTANT', 'Human Resources Assistant', '2016-08-30 16:08:31', '2016-08-30 08:08:32'),
(48, 70, 'MASALUNGA , ANNA P', '0000-00-00', 98, 'Corporate Rank', 'JR SPRVR', 'Junior Supervisor', '2016-08-30 16:08:47', '2016-08-30 08:08:48'),
(49, 164, 'NAVALES, KIMBERLY B', '0000-00-00', 25, 'Department', 'OPE', 'Operations', '2016-08-30 16:10:50', '2016-08-30 08:10:51'),
(50, 114, 'GARCIA, JOSEPH  A', '2016-01-01', 220, 'MOLIPS PH', 'EXEC', 'EXECUTIVE OFFICE', '2016-08-30 21:00:03', '2016-08-30 13:00:04'),
(51, 114, 'GARCIA, JOSEPH  A', '0000-00-00', 67, 'Job Position', 'General Manager', 'General Manager', '2016-08-31 14:42:33', '2016-08-31 06:42:34'),
(52, 114, 'GARCIA, JOSEPH  A', '0000-00-00', 20, 'Department', 'Management', 'Management', '2016-08-31 14:42:53', '2016-08-31 06:42:54'),
(53, 163, 'DELOS REYES, MARJORIE M', '0000-00-00', 235, 'MOL ASIA', 'LINER', 'LINER', '2016-09-01 09:19:47', '2016-09-01 01:19:48'),
(54, 163, 'DELOS REYES, MARJORIE M', '2016-08-03', 226, 'MOLIPS PH', 'LYM', 'LYM', '2016-09-01 09:20:11', '2016-09-01 01:20:12'),
(55, 163, 'DELOS REYES, MARJORIE M', '2016-08-03', 235, 'MOL ASIA', 'LINER', 'LINER', '2016-09-01 09:20:30', '2016-09-01 01:20:31'),
(56, 163, 'DELOS REYES, MARJORIE M', '2016-08-03', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-09-01 09:22:13', '2016-09-01 01:22:14'),
(57, 163, 'DELOS REYES, MARJORIE M', '2016-08-03', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-09-01 09:22:27', '2016-09-01 01:22:28'),
(58, 162, 'MACALINDONG, CHARLES KENNETH R', '2016-08-03', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-09-01 09:23:35', '2016-09-01 01:23:36'),
(59, 162, 'MACALINDONG, CHARLES KENNETH R', '2016-08-03', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-09-01 09:23:48', '2016-09-01 01:23:49'),
(60, 162, 'MACALINDONG, CHARLES KENNETH R', '2016-08-03', 235, 'MOL ASIA', 'LINER', 'LINER', '2016-09-01 09:24:01', '2016-09-01 01:24:02'),
(61, 162, 'MACALINDONG, CHARLES KENNETH R', '2016-08-03', 226, 'MOLIPS PH', 'LYM', 'LYM', '2016-09-01 09:24:21', '2016-09-01 01:24:22'),
(62, 164, 'NAVALES, KIMBERLY B', '2016-08-11', 25, 'Department', 'OPE', 'Operations', '2016-09-02 09:08:05', '2016-09-02 01:08:06'),
(63, 164, 'NAVALES, KIMBERLY B', '2016-08-11', 164, 'Employee Category', 'PRO', 'Probationary', '2016-09-02 09:08:33', '2016-09-02 01:08:34'),
(64, 164, 'NAVALES, KIMBERLY B', '2016-08-11', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-09-02 09:09:18', '2016-09-02 01:09:19'),
(65, 164, 'NAVALES, KIMBERLY B', '2016-08-11', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-09-02 09:10:31', '2016-09-02 01:10:32'),
(66, 164, 'NAVALES, KIMBERLY B', '2016-08-11', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-09-02 09:10:56', '2016-09-02 01:10:57'),
(67, 164, 'NAVALES, KIMBERLY B', '2016-08-11', 237, 'MOL ASIA', 'PHILS', 'PHILS', '2016-09-02 09:11:17', '2016-09-02 01:11:18'),
(68, 164, 'NAVALES, KIMBERLY B', '2016-08-11', 231, 'MOLIPS PH', 'PHGSA', 'PHGSA', '2016-09-02 09:11:35', '2016-09-02 01:11:36'),
(69, 164, 'NAVALES, KIMBERLY B', '2016-08-11', 231, 'MOLIPS PH', 'PHGSA', 'PHGSA', '2016-09-02 09:11:40', '2016-09-02 01:11:41'),
(70, 46, 'ALDHAMMOOR, ALI HASAN A', '2016-08-09', 163, 'Employee Category', 'REG', 'Regular', '2016-09-08 09:39:28', '2016-09-08 01:39:29'),
(71, 45, 'REYES, ANGELO A', '2016-08-01', 163, 'Employee Category', 'REG', 'Regular', '2016-09-08 09:40:12', '2016-09-08 01:40:13'),
(72, 48, 'ARCIAGA , AIREEN MAY G', '2016-08-22', 163, 'Employee Category', 'REG', 'Regular', '2016-09-08 09:42:59', '2016-09-08 01:43:00'),
(73, 49, 'CALALES, VINA MARIE  G', '2016-08-24', 163, 'Employee Category', 'REG', 'Regular', '2016-09-08 09:44:16', '2016-09-08 01:44:17'),
(74, 50, 'CALADO, MA. CRISELDA  T', '2016-08-24', 163, 'Employee Category', 'REG', 'Regular', '2016-09-08 09:49:50', '2016-09-08 01:49:51'),
(75, 51, 'CALUMBA, MARK LEE  R', '2016-08-24', 163, 'Employee Category', 'REG', 'Regular', '2016-09-08 09:50:24', '2016-09-08 01:50:25'),
(76, 52, 'EQUIZA, MAXIN ALLEN D', '2016-08-24', 163, 'Employee Category', 'REG', 'Regular', '2016-09-08 09:51:10', '2016-09-08 01:51:11'),
(77, 7, 'CABRERA , JUAN CARLOS S', '2016-03-01', 163, 'Employee Category', 'REG', 'Regular', '2016-09-14 19:28:25', '2016-09-14 11:28:26'),
(78, 165, 'MANALO, MONIQUE M', '2016-09-20', 164, 'Employee Category', 'PRO', 'Probationary', '2016-09-28 10:31:36', '2016-09-28 02:31:37'),
(79, 75, 'SAIN , CARLOS D', '2016-10-03', 237, 'MOL ASIA', 'PHILS', 'PHILS', '2016-10-01 09:03:17', '2016-10-01 01:03:19'),
(80, 75, 'SAIN , CARLOS D', '2016-10-03', 230, 'MOLIPS PH', 'PHE', 'PHE', '2016-10-01 09:03:50', '2016-10-01 01:03:51'),
(81, 54, 'SANTOS , IMELDA D', '0000-00-00', 229, 'MOLIPS PH', 'OPTR', 'OPERATIONS', '2016-10-06 18:46:20', '2016-10-06 10:46:21'),
(82, 53, 'DAYAG, MARIA EIMEE ANN REA D', '0000-00-00', 229, 'MOLIPS PH', 'OPTR', 'OPERATIONS', '2016-10-06 18:47:20', '2016-10-06 10:47:21'),
(83, 4, 'PERKINS, MARY GENE TAMIKO F', '2015-10-01', 222, 'MOLIPS PH', 'HRADMIN', 'HR & ADMINISTRATION', '2016-10-07 08:39:18', '2016-10-07 00:39:19'),
(84, 53, 'DAYAG, MARIA EIMEE ANN REA D', '2016-03-14', 229, 'MOLIPS PH', 'OPTR', 'OPERATIONS', '2016-10-07 08:41:35', '2016-10-07 00:41:36'),
(85, 54, 'SANTOS , IMELDA D', '2016-04-04', 229, 'MOLIPS PH', 'OPTR', 'OPERATIONS', '2016-10-07 08:42:43', '2016-10-07 00:42:44'),
(86, 70, 'MASALUNGA , ANNA P', '2016-06-01', 222, 'MOLIPS PH', 'HRADMIN', 'HR & ADMINISTRATION', '2016-10-07 08:46:01', '2016-10-07 00:46:02'),
(87, 181, 'CIPRES, JOHN KENNETH ', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 12:58:58', '2016-10-07 04:58:59'),
(88, 181, 'CIPRES, JOHN KENNETH ', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 12:59:15', '2016-10-07 04:59:16'),
(89, 181, 'CIPRES, JOHN KENNETH ', '2016-09-17', 270, 'MOL ASIA', 'USA', 'USA', '2016-10-07 12:59:31', '2016-10-07 04:59:32'),
(90, 181, 'CIPRES, JOHN KENNETH ', '2016-09-17', 274, 'MOLIPS PH', 'USBK', 'USBK', '2016-10-07 12:59:49', '2016-10-07 04:59:50'),
(91, 173, 'AREVALO, RACHEL MABEL P', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 13:41:13', '2016-10-07 05:41:14'),
(92, 173, 'AREVALO, RACHEL MABEL P', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 13:41:28', '2016-10-07 05:41:29'),
(93, 173, 'AREVALO, RACHEL MABEL P', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 13:41:48', '2016-10-07 05:41:49'),
(94, 173, 'AREVALO, RACHEL MABEL P', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-07 13:42:05', '2016-10-07 05:42:06'),
(95, 169, 'CLAVECILLAS, DONNA MAY A', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 13:44:35', '2016-10-07 05:44:36'),
(96, 169, 'CLAVECILLAS, DONNA MAY A', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 13:44:46', '2016-10-07 05:44:47'),
(97, 169, 'CLAVECILLAS, DONNA MAY A', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 13:45:02', '2016-10-07 05:45:03'),
(98, 169, 'CLAVECILLAS, DONNA MAY A', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-07 13:45:18', '2016-10-07 05:45:19'),
(99, 167, 'CONSULAR, GENEVE D', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 13:53:18', '2016-10-07 05:53:19'),
(100, 167, 'CONSULAR, GENEVE D', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 13:53:35', '2016-10-07 05:53:36'),
(101, 167, 'CONSULAR, GENEVE D', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 13:53:52', '2016-10-07 05:53:54'),
(102, 167, 'CONSULAR, GENEVE D', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 13:55:08', '2016-10-07 05:55:09'),
(103, 167, 'CONSULAR, GENEVE D', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 13:55:26', '2016-10-07 05:55:27'),
(104, 167, 'CONSULAR, GENEVE D', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 13:55:42', '2016-10-07 05:55:43'),
(105, 167, 'CONSULAR, GENEVE D', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-07 13:56:04', '2016-10-07 05:56:05'),
(106, 166, 'COSMIANO, JOHN PAUL U', '2016-09-20', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 13:56:45', '2016-10-07 05:56:46'),
(107, 166, 'COSMIANO, JOHN PAUL U', '2016-09-20', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 13:57:01', '2016-10-07 05:57:02'),
(108, 166, 'COSMIANO, JOHN PAUL U', '2016-09-20', 235, 'MOL ASIA', 'LINER', 'LINER', '2016-10-07 13:57:19', '2016-10-07 05:57:20'),
(109, 171, 'DE GUIA, JOHN CARLO N', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 13:59:41', '2016-10-07 05:59:42'),
(110, 171, 'DE GUIA, JOHN CARLO N', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 14:00:04', '2016-10-07 06:00:05'),
(111, 171, 'DE GUIA, JOHN CARLO N', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 14:00:20', '2016-10-07 06:00:21'),
(112, 171, 'DE GUIA, JOHN CARLO N', '2016-09-17', 224, 'MOLIPS PH', 'JPB', 'JPB', '2016-10-07 14:00:36', '2016-10-07 06:00:37'),
(113, 179, 'DE JESUS, JEFF  M', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 14:01:28', '2016-10-07 06:01:29'),
(114, 179, 'DE JESUS, JEFF  M', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 14:01:41', '2016-10-07 06:01:42'),
(115, 179, 'DE JESUS, JEFF  M', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 14:01:54', '2016-10-07 06:01:55'),
(116, 179, 'DE JESUS, JEFF  M', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-07 14:02:12', '2016-10-07 06:02:13'),
(117, 170, 'DICHOSA, MA. ELENA D', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 14:04:29', '2016-10-07 06:04:30'),
(118, 170, 'DICHOSA, MA. ELENA D', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 14:04:40', '2016-10-07 06:04:41'),
(119, 170, 'DICHOSA, MA. ELENA D', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 14:05:12', '2016-10-07 06:05:13'),
(120, 170, 'DICHOSA, MA. ELENA D', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-07 14:05:25', '2016-10-07 06:05:27'),
(121, 174, 'LIRIO , JUSTIN A', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 14:12:03', '2016-10-07 06:12:04'),
(122, 174, 'LIRIO , JUSTIN A', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 14:12:18', '2016-10-07 06:12:19'),
(123, 174, 'LIRIO , JUSTIN A', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 14:12:34', '2016-10-07 06:12:35'),
(124, 174, 'LIRIO , JUSTIN A', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-07 14:12:48', '2016-10-07 06:12:49'),
(125, 175, 'MAGCAWAS, FRANCIS EEVAN P', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 14:13:20', '2016-10-07 06:13:22'),
(126, 175, 'MAGCAWAS, FRANCIS EEVAN P', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 14:13:31', '2016-10-07 06:13:32'),
(127, 175, 'MAGCAWAS, FRANCIS EEVAN P', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 14:13:44', '2016-10-07 06:13:45'),
(128, 175, 'MAGCAWAS, FRANCIS EEVAN P', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 14:14:04', '2016-10-07 06:14:05'),
(129, 175, 'MAGCAWAS, FRANCIS EEVAN P', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-07 14:14:20', '2016-10-07 06:14:21'),
(130, 168, 'LOCQUIAO, NOEMI S', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 14:34:13', '2016-10-07 06:34:14'),
(131, 168, 'LOCQUIAO, NOEMI S', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 14:35:21', '2016-10-07 06:35:22'),
(132, 168, 'LOCQUIAO, NOEMI S', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 14:35:33', '2016-10-07 06:35:34'),
(133, 168, 'LOCQUIAO, NOEMI S', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 14:35:48', '2016-10-07 06:35:50'),
(134, 168, 'LOCQUIAO, NOEMI S', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-07 14:36:03', '2016-10-07 06:36:04'),
(135, 168, 'LOCQUIAO, NOEMI S', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 14:49:57', '2016-10-07 06:49:58'),
(136, 168, 'LOCQUIAO, NOEMI S', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-07 14:50:13', '2016-10-07 06:50:14'),
(137, 168, 'LOCQUIAO, NOEMI S', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 14:50:25', '2016-10-07 06:50:26'),
(138, 168, 'LOCQUIAO, NOEMI S', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 14:50:36', '2016-10-07 06:50:37'),
(139, 165, 'MANALO, MONIQUE M', '2016-09-20', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 14:52:06', '2016-10-07 06:52:07'),
(140, 165, 'MANALO, MONIQUE M', '2016-09-20', 235, 'MOL ASIA', 'LINER', 'LINER', '2016-10-07 14:52:49', '2016-10-07 06:52:50'),
(141, 165, 'MANALO, MONIQUE M', '2016-09-20', 226, 'MOLIPS PH', 'LYM', 'LYM', '2016-10-07 14:53:09', '2016-10-07 06:53:11'),
(142, 165, 'MANALO, MONIQUE M', '2016-09-20', 226, 'MOLIPS PH', 'LYM', 'LYM', '2016-10-07 15:43:48', '2016-10-07 07:43:49'),
(143, 176, 'MOLINA, ZANDER P', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 15:44:54', '2016-10-07 07:44:55'),
(144, 176, 'MOLINA, ZANDER P', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 15:45:08', '2016-10-07 07:45:09'),
(145, 176, 'MOLINA, ZANDER P', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 15:45:24', '2016-10-07 07:45:25'),
(146, 176, 'MOLINA, ZANDER P', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-07 15:45:40', '2016-10-07 07:45:41'),
(147, 172, 'MORALES, KEVIN RUSS V', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 15:46:09', '2016-10-07 07:46:10'),
(148, 172, 'MORALES, KEVIN RUSS V', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 15:46:22', '2016-10-07 07:46:23'),
(149, 172, 'MORALES, KEVIN RUSS V', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 15:46:39', '2016-10-07 07:46:40'),
(150, 172, 'MORALES, KEVIN RUSS V', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 15:47:24', '2016-10-07 07:47:25'),
(151, 172, 'MORALES, KEVIN RUSS V', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 15:48:37', '2016-10-07 07:48:38'),
(152, 172, 'MORALES, KEVIN RUSS V', '2016-09-17', 224, 'MOLIPS PH', 'JPB', 'JPB', '2016-10-07 15:48:56', '2016-10-07 07:48:57'),
(153, 177, 'QUEMA, DIANA  B', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 15:50:34', '2016-10-07 07:50:35'),
(154, 177, 'QUEMA, DIANA  B', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 15:50:44', '2016-10-07 07:50:45'),
(155, 177, 'QUEMA, DIANA  B', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-07 15:50:56', '2016-10-07 07:50:57'),
(156, 177, 'QUEMA, DIANA  B', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-07 15:51:14', '2016-10-07 07:51:15'),
(157, 165, 'MANALO, MONIQUE M', '2016-09-20', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-07 15:51:55', '2016-10-07 07:51:56'),
(158, 178, 'TANADA, MARK VINCENT S', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-07 15:52:51', '2016-10-07 07:52:52'),
(159, 178, 'TANADA, MARK VINCENT S', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-10 16:30:41', '2016-10-10 08:30:42'),
(160, 178, 'TANADA, MARK VINCENT S', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-10 16:30:53', '2016-10-10 08:30:54'),
(161, 178, 'TANADA, MARK VINCENT S', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-10 16:31:05', '2016-10-10 08:31:06'),
(162, 178, 'TANADA, MARK VINCENT S', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-10 16:31:23', '2016-10-10 08:31:24'),
(163, 180, 'TONGSON, ROBERT V', '2016-09-17', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-10 16:33:38', '2016-10-10 08:33:39'),
(164, 180, 'TONGSON, ROBERT V', '2016-09-17', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-10 16:36:56', '2016-10-10 08:36:57'),
(165, 180, 'TONGSON, ROBERT V', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-10 16:37:09', '2016-10-10 08:37:10'),
(166, 180, 'TONGSON, ROBERT V', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-10 16:37:22', '2016-10-10 08:37:23'),
(167, 166, 'COSMIANO, JOHN PAUL U', '2016-09-20', 226, 'MOLIPS PH', 'LYM', 'LYM', '2016-10-10 16:38:04', '2016-10-10 08:38:05'),
(168, 53, 'DAYAG, MARIA EIMEE ANN REA D', '2016-03-14', 50, 'Job Position', 'Assistant Operation Manager', 'Assistant Operation Manager', '2016-10-11 16:34:32', '2016-10-11 08:34:33'),
(169, 53, 'DAYAG, MARIA EIMEE ANN REA D', '2016-03-14', 25, 'Department', 'OPE', 'Operations', '2016-10-11 16:35:01', '2016-10-11 08:35:02'),
(170, 89, 'MACAPAGAL , KAREN V', '2016-06-20', 50, 'Job Position', 'Assistant Operation Manager', 'Assistant Operation Manager', '2016-10-11 16:36:26', '2016-10-11 08:36:27'),
(171, 108, 'ISAAC , ARLENE A', '2016-10-11', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-12 10:28:26', '2016-10-12 02:28:27'),
(172, 108, 'ISAAC , ARLENE A', '2016-10-11', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-12 10:28:48', '2016-10-12 02:28:49'),
(173, 54, 'SANTOS , IMELDA D', '0000-00-00', 237, 'MOL ASIA', 'PHILS', 'PHILS', '2016-10-12 14:33:22', '2016-10-12 06:33:23'),
(174, 53, 'DAYAG, MARIA EIMEE ANN REA D', '0000-00-00', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-12 14:35:02', '2016-10-12 06:35:03'),
(175, 37, 'NISPEROS, ANTHONY BRYAN  R', '0000-00-00', 237, 'MOL ASIA', 'PHILS', 'PHILS', '2016-10-18 14:51:29', '2016-10-18 06:51:30'),
(176, 29, 'LORESTO, KATHLEEN A', '2016-10-01', 50, 'Job Position', 'Assistant Operation Manager', 'Assistant Operation Manager', '2016-10-19 10:53:40', '2016-10-19 02:53:41'),
(177, 29, 'LORESTO, KATHLEEN A', '2016-10-01', 99, 'Corporate Rank', 'ASSIST MNGR', 'Assistant Manager', '2016-10-19 10:53:56', '2016-10-19 02:53:57'),
(178, 78, 'MANALOTO , JOSHUA E', '2016-10-01', 235, 'MOL ASIA', 'LINER', 'LINER', '2016-10-19 11:38:40', '2016-10-19 03:38:41'),
(179, 78, 'MANALOTO , JOSHUA E', '2016-10-01', 226, 'MOLIPS PH', 'LYM', 'LYM', '2016-10-19 11:39:02', '2016-10-19 03:39:03'),
(180, 53, 'DAYAG, MARIA EIMEE ANN REA D', '0000-00-00', 238, 'MOL ASIA', 'SUPPORT', 'SUPPORT ', '2016-10-19 11:41:18', '2016-10-19 03:41:19'),
(181, 53, 'DAYAG, MARIA EIMEE ANN REA D', '0000-00-00', 229, 'MOLIPS PH', 'OPTR', 'OPERATIONS', '2016-10-19 11:41:43', '2016-10-19 03:41:44'),
(182, 54, 'SANTOS , IMELDA D', '0000-00-00', 238, 'MOL ASIA', 'SUPPORT', 'SUPPORT ', '2016-10-19 11:42:25', '2016-10-19 03:42:26'),
(183, 6, 'BELCHES, MEINARD  B', '0000-00-00', 238, 'MOL ASIA', 'SUPPORT', 'SUPPORT ', '2016-10-19 11:46:27', '2016-10-19 03:46:28'),
(184, 6, 'BELCHES, MEINARD  B', '0000-00-00', 229, 'MOLIPS PH', 'OPTR', 'OPERATIONS', '2016-10-19 11:46:37', '2016-10-19 03:46:38'),
(185, 167, 'CONSULAR, GENEVE D', '0000-00-00', 238, 'MOL ASIA', 'SUPPORT', 'SUPPORT ', '2016-10-19 11:47:17', '2016-10-19 03:47:18'),
(186, 167, 'CONSULAR, GENEVE D', '0000-00-00', 229, 'MOLIPS PH', 'OPTR', 'OPERATIONS', '2016-10-19 11:47:27', '2016-10-19 03:47:28'),
(187, 177, 'QUEMA, DIANA  B', '0000-00-00', 238, 'MOL ASIA', 'SUPPORT', 'SUPPORT ', '2016-10-19 11:48:01', '2016-10-19 03:48:02'),
(188, 177, 'QUEMA, DIANA  B', '0000-00-00', 229, 'MOLIPS PH', 'OPTR', 'OPERATIONS', '2016-10-19 11:48:13', '2016-10-19 03:48:14'),
(189, 69, 'ASTILLO , GENEVA G', '0000-00-00', 229, 'MOLIPS PH', 'OPTR', 'OPERATIONS', '2016-10-19 11:49:14', '2016-10-19 03:49:15'),
(190, 181, 'CIPRES, JOHN KENNETH ', '0000-00-00', 238, 'MOL ASIA', 'SUPPORT', 'SUPPORT ', '2016-10-19 11:49:57', '2016-10-19 03:49:58'),
(191, 181, 'CIPRES, JOHN KENNETH ', '0000-00-00', 229, 'MOLIPS PH', 'OPTR', 'OPERATIONS', '2016-10-19 11:50:08', '2016-10-19 03:50:09'),
(192, 70, 'MASALUNGA , ANNA P', '2016-06-01', 42, 'Job Position', 'HR & ADMIN OFFICER', 'HR & Admin Officer', '2016-10-19 16:11:08', '2016-10-19 08:11:09'),
(193, 182, 'SAMSON, DONVER T', '2015-10-01', 0, '', '', '', '2016-10-19 17:51:03', '2016-10-19 09:51:04'),
(194, 182, 'SAMSON, DONVER T', '2015-10-01', 95, 'Corporate Rank', 'JR STAFF', 'Junior Staff', '2016-10-19 17:51:03', '2016-10-19 09:51:04'),
(195, 182, 'SAMSON, DONVER T', '2015-10-01', 17, 'Location', 'HOF', 'Head Office', '2016-10-19 17:51:03', '2016-10-19 09:51:04'),
(196, 182, 'SAMSON, DONVER T', '2015-10-01', 24, 'Department', 'HRA', 'HR & Administration', '2016-10-19 17:51:03', '2016-10-19 09:51:04'),
(197, 182, 'SAMSON, DONVER T', '2015-10-01', 166, 'Employee Category', 'TEMP', 'Temporary', '2016-10-19 17:51:03', '2016-10-19 09:51:04'),
(198, 182, 'SAMSON, DONVER T', '2015-10-01', 247, 'PEZA Section', 'N/A', 'N/A', '2016-10-19 17:51:03', '2016-10-19 09:51:04'),
(199, 182, 'SAMSON, DONVER T', '2015-10-01', 246, 'PEZA SubSection', 'N/A', 'N/A', '2016-10-19 17:51:03', '2016-10-19 09:51:04'),
(200, 182, 'SAMSON, DONVER T', '2015-10-01', 245, 'MOL ASIA', 'N/A', 'N/A', '2016-10-19 17:51:03', '2016-10-19 09:51:04'),
(201, 182, 'SAMSON, DONVER T', '2015-10-01', 244, 'MOLIPS PH', 'N/A', 'N/A', '2016-10-19 17:51:03', '2016-10-19 09:51:04'),
(202, 76, 'SADIE , MELVIN M', '2016-10-24', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-24 08:16:42', '2016-10-24 00:16:43'),
(203, 76, 'SADIE , MELVIN M', '2016-10-24', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-24 08:16:56', '2016-10-24 00:16:57'),
(204, 33, 'BALNEG , BANJO M', '2016-10-24', 224, 'MOLIPS PH', 'JPB', 'JPB', '2016-10-24 08:19:23', '2016-10-24 00:19:24'),
(205, 61, 'LIBRE, WILDINE MAE P', '2016-10-22', 163, 'Employee Category', 'REG', 'Regular', '2016-10-24 09:01:28', '2016-10-24 01:01:29'),
(206, 57, 'VINEGA, EZEKIEL G', '2016-10-22', 163, 'Employee Category', 'REG', 'Regular', '2016-10-24 09:34:58', '2016-10-24 01:35:00'),
(207, 58, 'SATINGIN , HAZELLE S', '2016-10-22', 163, 'Employee Category', 'REG', 'Regular', '2016-10-24 09:35:52', '2016-10-24 01:35:54'),
(208, 59, 'MEDINA, ALLEN JAY  S', '2016-10-22', 163, 'Employee Category', 'REG', 'Regular', '2016-10-24 09:59:16', '2016-10-24 01:59:17'),
(209, 55, 'LADUB , MA. JANSELLE E', '2016-10-22', 163, 'Employee Category', 'REG', 'Regular', '2016-10-24 10:01:25', '2016-10-24 02:01:26'),
(210, 60, 'LINTOT , CHARINA M', '2016-10-22', 163, 'Employee Category', 'REG', 'Regular', '2016-10-24 10:11:41', '2016-10-24 02:11:42'),
(211, 183, 'SERRANO, CEDRICK G', '2016-10-24', 65, 'Job Position', 'JR Information Analyst', 'JR Information Analyst', '2016-10-24 15:22:11', '2016-10-24 07:22:12'),
(212, 183, 'SERRANO, CEDRICK G', '2016-10-24', 95, 'Corporate Rank', 'JR STAFF', 'Junior Staff', '2016-10-24 15:22:11', '2016-10-24 07:22:12'),
(213, 183, 'SERRANO, CEDRICK G', '2016-10-24', 17, 'Location', 'HOF', 'Head Office', '2016-10-24 15:22:11', '2016-10-24 07:22:12'),
(214, 183, 'SERRANO, CEDRICK G', '2016-10-24', 25, 'Department', 'OPE', 'Operations', '2016-10-24 15:22:11', '2016-10-24 07:22:12'),
(215, 183, 'SERRANO, CEDRICK G', '2016-10-24', 163, 'Employee Category', 'REG', 'Regular', '2016-10-24 15:22:11', '2016-10-24 07:22:12'),
(216, 183, 'SERRANO, CEDRICK G', '2016-10-24', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-10-24 15:22:11', '2016-10-24 07:22:12'),
(217, 183, 'SERRANO, CEDRICK G', '2016-10-24', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-10-24 15:22:11', '2016-10-24 07:22:12'),
(218, 183, 'SERRANO, CEDRICK G', '2016-10-24', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-24 15:22:11', '2016-10-24 07:22:12'),
(219, 183, 'SERRANO, CEDRICK G', '2016-10-24', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-24 15:22:11', '2016-10-24 07:22:12'),
(220, 167, 'CONSULAR, GENEVE D', '2016-09-17', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-10-27 16:27:39', '2016-10-27 08:27:40'),
(221, 167, 'CONSULAR, GENEVE D', '2016-09-17', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-10-27 16:27:55', '2016-10-27 08:27:56'),
(222, 183, 'SERRANO, CEDRICK G', '2016-10-24', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-11-02 16:41:39', '2016-11-02 08:41:40'),
(223, 183, 'SERRANO, CEDRICK G', '2016-10-24', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-11-02 16:41:56', '2016-11-02 08:41:57'),
(224, 183, 'SERRANO, CEDRICK G', '2016-10-24', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-11-02 16:42:17', '2016-11-02 08:42:18'),
(225, 183, 'SERRANO, CEDRICK G', '2016-10-24', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-11-02 16:42:37', '2016-11-02 08:42:39'),
(226, 167, 'CONSULAR, GENEVE D', '0000-00-00', 238, 'MOL ASIA', 'SUPPORT', 'SUPPORT ', '2016-11-03 17:18:08', '2016-11-03 09:18:09'),
(227, 167, 'CONSULAR, GENEVE D', '0000-00-00', 229, 'MOLIPS PH', 'OPTR', 'OPERATIONS', '2016-11-03 17:18:24', '2016-11-03 09:18:25'),
(228, 56, 'DOMINGO  , JULITO P', '2016-10-22', 163, 'Employee Category', 'REG', 'Regular', '2016-11-11 16:17:54', '2016-11-11 08:17:55'),
(229, 65, 'ESTRADA , TRISHA F', '2016-11-10', 163, 'Employee Category', 'REG', 'Regular', '2016-11-11 16:26:01', '2016-11-11 08:26:02'),
(230, 67, 'LOPEZ , LARRY E', '2016-11-01', 163, 'Employee Category', 'REG', 'Regular', '2016-11-14 09:17:23', '2016-11-14 01:17:24'),
(231, 62, 'SALVADOR, CHRISTOPHER T', '2016-11-02', 163, 'Employee Category', 'REG', 'Regular', '2016-11-14 12:21:32', '2016-11-14 04:21:33'),
(232, 85, 'RIBLEZA, LOUIS ROBERT  E', '2016-11-01', 163, 'Employee Category', 'REG', 'Regular', '2016-11-15 15:56:55', '2016-11-15 07:56:56'),
(233, 184, 'SACRIZ, SUZETTE D', '2016-11-21', 65, 'Job Position', 'JR Information Analyst', 'JR Information Analyst', '2016-11-22 10:22:17', '2016-11-22 02:22:18'),
(234, 184, 'SACRIZ, SUZETTE D', '2016-11-21', 95, 'Corporate Rank', 'JR STAFF', 'Junior Staff', '2016-11-22 10:22:17', '2016-11-22 02:22:18'),
(235, 184, 'SACRIZ, SUZETTE D', '2016-11-21', 17, 'Location', 'HOF', 'Head Office', '2016-11-22 10:22:17', '2016-11-22 02:22:19'),
(236, 184, 'SACRIZ, SUZETTE D', '2016-11-21', 25, 'Department', 'OPE', 'Operations', '2016-11-22 10:22:17', '2016-11-22 02:22:19'),
(237, 184, 'SACRIZ, SUZETTE D', '2016-11-21', 164, 'Employee Category', 'PRO', 'Probationary', '2016-11-22 10:22:17', '2016-11-22 02:22:19'),
(238, 184, 'SACRIZ, SUZETTE D', '2016-11-21', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-11-22 10:22:17', '2016-11-22 02:22:19'),
(239, 184, 'SACRIZ, SUZETTE D', '2016-11-21', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-11-22 10:22:17', '2016-11-22 02:22:19'),
(240, 184, 'SACRIZ, SUZETTE D', '2016-11-21', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-11-22 10:22:17', '2016-11-22 02:22:19'),
(241, 184, 'SACRIZ, SUZETTE D', '2016-11-21', 224, 'MOLIPS PH', 'JPB', 'JPB', '2016-11-22 10:22:17', '2016-11-22 02:22:19'),
(242, 185, 'SORIANO, EDGLO S', '2016-11-21', 65, 'Job Position', 'JR Information Analyst', 'JR Information Analyst', '2016-11-22 10:27:29', '2016-11-22 02:27:30'),
(243, 185, 'SORIANO, EDGLO S', '2016-11-21', 95, 'Corporate Rank', 'JR STAFF', 'Junior Staff', '2016-11-22 10:27:29', '2016-11-22 02:27:30'),
(244, 185, 'SORIANO, EDGLO S', '2016-11-21', 17, 'Location', 'HOF', 'Head Office', '2016-11-22 10:27:29', '2016-11-22 02:27:30'),
(245, 185, 'SORIANO, EDGLO S', '2016-11-21', 20, 'Department', 'Management', 'Management', '2016-11-22 10:27:29', '2016-11-22 02:27:30'),
(246, 185, 'SORIANO, EDGLO S', '2016-11-21', 163, 'Employee Category', 'REG', 'Regular', '2016-11-22 10:27:29', '2016-11-22 02:27:30'),
(247, 185, 'SORIANO, EDGLO S', '2016-11-21', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-11-22 10:27:29', '2016-11-22 02:27:30'),
(248, 185, 'SORIANO, EDGLO S', '2016-11-21', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-11-22 10:27:29', '2016-11-22 02:27:30'),
(249, 185, 'SORIANO, EDGLO S', '2016-11-21', 234, 'MOL ASIA', 'JAPAN', 'JAPAN', '2016-11-22 10:27:29', '2016-11-22 02:27:30'),
(250, 185, 'SORIANO, EDGLO S', '2016-11-21', 225, 'MOLIPS PH', 'JPE', 'JPE', '2016-11-22 10:27:29', '2016-11-22 02:27:30'),
(251, 186, 'SABAYAN, KIM MADELAINE C', '2016-11-21', 280, 'Job Position', 'OJT', 'Intern', '2016-11-22 10:42:41', '2016-11-22 02:42:43'),
(252, 186, 'SABAYAN, KIM MADELAINE C', '2016-11-21', 95, 'Corporate Rank', 'JR STAFF', 'Junior Staff', '2016-11-22 10:42:41', '2016-11-22 02:42:43'),
(253, 186, 'SABAYAN, KIM MADELAINE C', '2016-11-21', 17, 'Location', 'HOF', 'Head Office', '2016-11-22 10:42:41', '2016-11-22 02:42:43'),
(254, 186, 'SABAYAN, KIM MADELAINE C', '2016-11-21', 24, 'Department', 'HRA', 'HR & Administration', '2016-11-22 10:42:41', '2016-11-22 02:42:43'),
(255, 186, 'SABAYAN, KIM MADELAINE C', '2016-11-21', 166, 'Employee Category', 'TEMP', 'Temporary', '2016-11-22 10:42:41', '2016-11-22 02:42:43'),
(256, 186, 'SABAYAN, KIM MADELAINE C', '2016-11-21', 241, 'PEZA Section', 'DIRECT', 'DIRECT', '2016-11-22 10:42:41', '2016-11-22 02:42:43'),
(257, 186, 'SABAYAN, KIM MADELAINE C', '2016-11-21', 275, 'PEZA SubSection', 'REGULAR', 'REGULAR', '2016-11-22 10:42:41', '2016-11-22 02:42:43'),
(258, 186, 'SABAYAN, KIM MADELAINE C', '2016-11-21', 245, 'MOL ASIA', 'N/A', 'N/A', '2016-11-22 10:42:41', '2016-11-22 02:42:43'),
(259, 186, 'SABAYAN, KIM MADELAINE C', '2016-11-21', 222, 'MOLIPS PH', 'HRADMIN', 'HR & ADMINISTRATION', '2016-11-22 10:42:41', '2016-11-22 02:42:43'),
(260, 186, 'SABAYAN, KIM MADELAINE C', '2016-11-21', 247, 'PEZA Section', 'N/A', 'N/A', '2016-11-22 10:45:32', '2016-11-22 02:45:33'),
(261, 186, 'SABAYAN, KIM MADELAINE C', '2016-11-21', 246, 'PEZA SubSection', 'N/A', 'N/A', '2016-11-22 10:45:52', '2016-11-22 02:45:53'),
(262, 187, 'ROSETE, CHERRY ANN M', '2016-11-21', 280, 'Job Position', 'OJT', 'Intern', '2016-11-22 10:51:54', '2016-11-22 02:51:55'),
(263, 187, 'ROSETE, CHERRY ANN M', '2016-11-21', 95, 'Corporate Rank', 'JR STAFF', 'Junior Staff', '2016-11-22 10:51:54', '2016-11-22 02:51:55'),
(264, 187, 'ROSETE, CHERRY ANN M', '2016-11-21', 17, 'Location', 'HOF', 'Head Office', '2016-11-22 10:51:54', '2016-11-22 02:51:55'),
(265, 187, 'ROSETE, CHERRY ANN M', '2016-11-21', 24, 'Department', 'HRA', 'HR & Administration', '2016-11-22 10:51:54', '2016-11-22 02:51:55'),
(266, 187, 'ROSETE, CHERRY ANN M', '2016-11-21', 166, 'Employee Category', 'TEMP', 'Temporary', '2016-11-22 10:51:54', '2016-11-22 02:51:55'),
(267, 187, 'ROSETE, CHERRY ANN M', '2016-11-21', 247, 'PEZA Section', 'N/A', 'N/A', '2016-11-22 10:51:54', '2016-11-22 02:51:55'),
(268, 187, 'ROSETE, CHERRY ANN M', '2016-11-21', 246, 'PEZA SubSection', 'N/A', 'N/A', '2016-11-22 10:51:54', '2016-11-22 02:51:55'),
(269, 187, 'ROSETE, CHERRY ANN M', '2016-11-21', 245, 'MOL ASIA', 'N/A', 'N/A', '2016-11-22 10:51:54', '2016-11-22 02:51:55'),
(270, 187, 'ROSETE, CHERRY ANN M', '2016-11-21', 222, 'MOLIPS PH', 'HRADMIN', 'HR & ADMINISTRATION', '2016-11-22 10:51:54', '2016-11-22 02:51:55'),
(271, 188, 'ROJALES, HARVEY RENCE O', '2016-11-21', 280, 'Job Position', 'OJT', 'Intern', '2016-11-22 10:56:58', '2016-11-22 02:56:59'),
(272, 188, 'ROJALES, HARVEY RENCE O', '2016-11-21', 95, 'Corporate Rank', 'JR STAFF', 'Junior Staff', '2016-11-22 10:56:58', '2016-11-22 02:56:59'),
(273, 188, 'ROJALES, HARVEY RENCE O', '2016-11-21', 17, 'Location', 'HOF', 'Head Office', '2016-11-22 10:56:58', '2016-11-22 02:56:59'),
(274, 188, 'ROJALES, HARVEY RENCE O', '2016-11-21', 22, 'Department', 'MIS', 'MIS', '2016-11-22 10:56:58', '2016-11-22 02:56:59'),
(275, 188, 'ROJALES, HARVEY RENCE O', '2016-11-21', 166, 'Employee Category', 'TEMP', 'Temporary', '2016-11-22 10:56:58', '2016-11-22 02:56:59'),
(276, 188, 'ROJALES, HARVEY RENCE O', '2016-11-21', 247, 'PEZA Section', 'N/A', 'N/A', '2016-11-22 10:56:58', '2016-11-22 02:56:59'),
(277, 188, 'ROJALES, HARVEY RENCE O', '2016-11-21', 246, 'PEZA SubSection', 'N/A', 'N/A', '2016-11-22 10:56:58', '2016-11-22 02:56:59'),
(278, 188, 'ROJALES, HARVEY RENCE O', '2016-11-21', 245, 'MOL ASIA', 'N/A', 'N/A', '2016-11-22 10:56:58', '2016-11-22 02:56:59'),
(279, 188, 'ROJALES, HARVEY RENCE O', '2016-11-21', 227, 'MOLIPS PH', 'MIS', 'MIS', '2016-11-22 10:56:58', '2016-11-22 02:56:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hris_employee_salary`
--

CREATE TABLE `tbl_hris_employee_salary` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `salary_description` varchar(255) DEFAULT '-',
  `payroll_setup` enum('semi-monthly') NOT NULL DEFAULT 'semi-monthly',
  `earning_type` int(11) NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `type_name` varchar(255) NOT NULL,
  `period` int(11) NOT NULL DEFAULT '0',
  `current_salary` double NOT NULL DEFAULT '0',
  `salary_increase` double NOT NULL DEFAULT '0',
  `amount` double NOT NULL,
  `effectivity_date` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `disabled` int(11) NOT NULL DEFAULT '0',
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `old_ref` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hris_employee_trainings_seminars`
--

CREATE TABLE `tbl_hris_employee_trainings_seminars` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_bio`
--

CREATE TABLE `tbl_tk_bio` (
  `id` int(11) NOT NULL,
  `temp_id` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `bio_id` int(11) NOT NULL DEFAULT '0',
  `ip_address` varchar(15) NOT NULL DEFAULT '-',
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_bio_setup`
--

CREATE TABLE `tbl_tk_bio_setup` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(20) DEFAULT NULL,
  `port_no` int(11) DEFAULT NULL,
  `mode_type` varchar(10) DEFAULT '-',
  `device_location` varchar(20) DEFAULT NULL,
  `office_location` varchar(20) DEFAULT NULL,
  `device_info` varchar(25) NOT NULL,
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_change_schedule`
--

CREATE TABLE `tbl_tk_change_schedule` (
  `id` int(11) NOT NULL,
  `user_id` varchar(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `no_of_days` int(11) NOT NULL,
  `change_type` varchar(255) NOT NULL,
  `change_time` varchar(255) NOT NULL,
  `dates` varchar(255) NOT NULL,
  `include_schedule` varchar(255) NOT NULL,
  `time_in` varchar(255) NOT NULL,
  `time_out` varchar(255) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '''0=For Approval'', ''1=Approved'', ''2=Disapproved''',
  `remarks` varchar(100) DEFAULT NULL,
  `approved_by_id` int(11) DEFAULT '0',
  `approved_by` varchar(150) DEFAULT '-',
  `approved_date` datetime DEFAULT '0000-00-00 00:00:00',
  `approved_code` varchar(25) DEFAULT '-',
  `approved_link` varchar(255) NOT NULL DEFAULT '-',
  `approved_source` varchar(15) DEFAULT '' COMMENT 'web/email/sms',
  `request_source` varchar(15) DEFAULT 'web' COMMENT 'web/sms',
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `approver_list` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_leave`
--

CREATE TABLE `tbl_tk_leave` (
  `id` int(11) NOT NULL,
  `employee_uid` int(11) NOT NULL DEFAULT '0',
  `employee_id` varchar(11) DEFAULT '-',
  `fullname` varchar(255) NOT NULL DEFAULT '-',
  `leave_type` varchar(20) NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `no_days` float NOT NULL DEFAULT '0.5',
  `resume_date` date DEFAULT NULL,
  `d_array` text NOT NULL,
  `h_array` text NOT NULL,
  `p_array` text NOT NULL,
  `leave_reason` varchar(255) NOT NULL DEFAULT '-',
  `with_pay` float(3,1) NOT NULL DEFAULT '0.0',
  `without_pay` float(3,1) NOT NULL DEFAULT '0.0',
  `status` int(3) NOT NULL DEFAULT '0' COMMENT '''0=For Approval'', ''1=Approved'', ''2=Disapproved''',
  `remarks` varchar(100) DEFAULT NULL,
  `date_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` datetime DEFAULT '0000-00-00 00:00:00',
  `approved_by_id` int(11) NOT NULL DEFAULT '0',
  `approved_by` varchar(150) NOT NULL DEFAULT '-',
  `approved_date` datetime DEFAULT '0000-00-00 00:00:00',
  `approved_code` varchar(255) DEFAULT '-',
  `approved_link` varchar(255) NOT NULL DEFAULT '-',
  `approved_source` varchar(15) DEFAULT 'web' COMMENT 'web/email/sms',
  `request_source` varchar(15) DEFAULT 'web' COMMENT 'web/sms',
  `special_leave` varchar(20) DEFAULT NULL,
  `attachment` text,
  `file_id` text,
  `approver_list` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_logs`
--

CREATE TABLE `tbl_tk_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `module` varchar(50) NOT NULL,
  `action` enum('insert','update','delete','upload','approve','disapprove','adapt','compute','export') NOT NULL,
  `type` enum('form','upload','email') NOT NULL DEFAULT 'form',
  `details` text NOT NULL,
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_overtime`
--

CREATE TABLE `tbl_tk_overtime` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `employee_id` varchar(11) DEFAULT NULL,
  `fullname` varchar(255) NOT NULL DEFAULT '-',
  `include_time` varchar(255) NOT NULL,
  `overtime_date_from` date NOT NULL,
  `overtime_date_to` date NOT NULL,
  `overtime_date` varchar(255) DEFAULT NULL,
  `overtime_from` varchar(255) DEFAULT NULL,
  `overtime_to` varchar(255) DEFAULT NULL,
  `overtime_break` varchar(255) NOT NULL,
  `overtime_hours` varchar(5) DEFAULT NULL,
  `no_of_days` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `overtime_for` enum('Pay','Offset') NOT NULL DEFAULT 'Pay',
  `status` int(3) NOT NULL DEFAULT '0' COMMENT '''0=For Approval'', ''1=Approved'', ''2=Disapproved''',
  `remarks` varchar(100) NOT NULL DEFAULT '-',
  `date_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` datetime DEFAULT '0000-00-00 00:00:00',
  `approved_by_id` int(11) DEFAULT '0',
  `approved_by` varchar(150) DEFAULT '-',
  `approved_date` datetime DEFAULT '0000-00-00 00:00:00',
  `approved_code` varchar(255) NOT NULL DEFAULT '-',
  `approved_link` varchar(255) NOT NULL DEFAULT '-',
  `approved_source` varchar(15) DEFAULT 'web' COMMENT 'web/email/sms',
  `request_source` varchar(15) DEFAULT 'web' COMMENT 'web/sms',
  `approver_list` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tk_schedule_lookup`
--

CREATE TABLE `tbl_tk_schedule_lookup` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(150) NOT NULL DEFAULT '-',
  `date` date NOT NULL,
  `dayname` varchar(10) DEFAULT NULL,
  `prefix` varchar(10) DEFAULT NULL,
  `schedule_code` varchar(25) NOT NULL,
  `schedule_status` varchar(25) NOT NULL,
  `schedule_in` varchar(5) DEFAULT NULL,
  `schedule_out` varchar(5) DEFAULT NULL,
  `in` varchar(5) DEFAULT NULL,
  `out` varchar(5) DEFAULT NULL,
  `hours` varchar(7) NOT NULL DEFAULT '0',
  `remarks` text,
  `date_updated` datetime NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_tk_in_out_raw`
--

CREATE TABLE `tb_tk_in_out_raw` (
  `id` int(11) NOT NULL,
  `count` int(11) DEFAULT NULL,
  `user_id` varchar(45) DEFAULT NULL,
  `verifyMode` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `Date` varchar(45) DEFAULT NULL,
  `time` varchar(45) DEFAULT NULL,
  `timedate` datetime DEFAULT NULL,
  `ip_address` varchar(15) NOT NULL,
  `ip_remote` varchar(15) DEFAULT '-',
  `mode_type` varchar(10) NOT NULL,
  `workCode` varchar(45) DEFAULT NULL,
  `reserved` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_hris_employee_dependent`
--
ALTER TABLE `tbl_hris_employee_dependent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_hris_employee_education`
--
ALTER TABLE `tbl_hris_employee_education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_hris_employee_info`
--
ALTER TABLE `tbl_hris_employee_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_hris_employee_movement`
--
ALTER TABLE `tbl_hris_employee_movement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_hris_employee_salary`
--
ALTER TABLE `tbl_hris_employee_salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_hris_employee_trainings_seminars`
--
ALTER TABLE `tbl_hris_employee_trainings_seminars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_bio`
--
ALTER TABLE `tbl_tk_bio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_bio_setup`
--
ALTER TABLE `tbl_tk_bio_setup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_change_schedule`
--
ALTER TABLE `tbl_tk_change_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_leave`
--
ALTER TABLE `tbl_tk_leave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_logs`
--
ALTER TABLE `tbl_tk_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_overtime`
--
ALTER TABLE `tbl_tk_overtime`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tk_schedule_lookup`
--
ALTER TABLE `tbl_tk_schedule_lookup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_tk_in_out_raw`
--
ALTER TABLE `tb_tk_in_out_raw`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_hris_employee_dependent`
--
ALTER TABLE `tbl_hris_employee_dependent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_hris_employee_education`
--
ALTER TABLE `tbl_hris_employee_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_hris_employee_info`
--
ALTER TABLE `tbl_hris_employee_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_hris_employee_movement`
--
ALTER TABLE `tbl_hris_employee_movement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=280;
--
-- AUTO_INCREMENT for table `tbl_hris_employee_salary`
--
ALTER TABLE `tbl_hris_employee_salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_hris_employee_trainings_seminars`
--
ALTER TABLE `tbl_hris_employee_trainings_seminars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_bio`
--
ALTER TABLE `tbl_tk_bio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_bio_setup`
--
ALTER TABLE `tbl_tk_bio_setup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_change_schedule`
--
ALTER TABLE `tbl_tk_change_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_leave`
--
ALTER TABLE `tbl_tk_leave`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_logs`
--
ALTER TABLE `tbl_tk_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_overtime`
--
ALTER TABLE `tbl_tk_overtime`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_tk_schedule_lookup`
--
ALTER TABLE `tbl_tk_schedule_lookup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tb_tk_in_out_raw`
--
ALTER TABLE `tb_tk_in_out_raw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
