<?php 
class Dashboard extends Ci_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		

		$data['title'] = 'Dashboard';
		//$this->load->view('welcome_message');
		$this->load->view('admin/header', $data);
		$this->load->view('admin/dashboard_view');

	}
}
