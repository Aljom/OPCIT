<?php

class Account_settings extends CI_Controller{

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper(array('form', 'url'));
	}

	public function index(){

		$data['title'] = 'Dashboard';
		$this->load->view('admin/header', $data);
		$this->load->view("admin/account_settings_view", $data);

	}

}

?>