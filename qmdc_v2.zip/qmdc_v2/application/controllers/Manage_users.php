<?php 
class Manage_users extends Ci_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{

		if(isset($_POST['btnAdd'])){
			$values = array('first_name'	=>$this->input->post("first_name",true),
							'last_name'		=>$this->input->post("last_name",true),
							'user_level'	=>$this->input->post("user_level",true),
							'department'	=>$this->input->post("department",true),
							'email'			=>$this->input->post("email",true),
							'username'		=>$this->input->post("username",true),
							'password'		=>$this->input->post("password",true));

			$this->Main_model->addNewUsers($values);
		}
		if(isset($_POST['deleteUser'])){

			$this->Main_model->deleteUser($this->input->post("user_id",true));
		}
		if(isset($_POST['btnSave'])){
			$id = $this->input->post("user_id2",true);
			$values = array('first_name'	=>$this->input->post("first_name2",true),
							'last_name'		=>$this->input->post("last_name2",true),
							'user_level'	=>$this->input->post("user_level2",true),
							'department'	=>$this->input->post("department2",true),
							'email'			=>$this->input->post("email2",true),
							'username'		=>$this->input->post("username2",true),
							'password'		=>$this->input->post("password2",true));
			
			$this->Main_model->updateUser($id,$values);

		}



		$data['title'] = 'Manage Users';
		$data['users'] = $this->Main_model->getUsers();
		$data['department'] = $this->Main_model->getDepartment();
	
		$this->load->view('admin/header', $data);
		$this->load->view('admin/manage_users_view', $data);

	}
}
