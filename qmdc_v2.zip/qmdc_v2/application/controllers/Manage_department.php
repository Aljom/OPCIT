<?php
class Manage_department extends Ci_Controller
{
	function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		$data['title'] = 'Manage Department';
		$data['department'] = $this->Main_model->getDepartment();
	
		$this->load->view('admin/header', $data);
		$this->load->view('admin/manage_department_view', $data);

		if(isset($_POST['btnAdd'])){
			$values = array('department_name'	=>$this->input->post("department_name",true),
							'description' 		=>$this->input->post("description",true));

			$this->Main_model->addNewDepartment($values);
			//header('Refresh: 0');
			$data['success'] = "Successfully Updated!";
		}
		if(isset($_POST['btnSave'])){
			$id = $this->input->post("user_id2",true);
			$values = array('department_name'	=>$this->input->post("department_name2",true),
							'description' 		=>$this->input->post("description2",true));


			$this->Main_model->updateDepartment($id,$values);
			//header('Refresh: 0');
			$data['success'] = "Successfully Updated!";
		}
		if(isset($_POST['deleteBtn'])){

			$this->Main_model->deleteDept($this->input->post("user_id",true));
			$data['success'] = "Successfully Updated!";
		}


	}
}


?>