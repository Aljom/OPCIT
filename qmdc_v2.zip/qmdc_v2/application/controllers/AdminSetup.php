<?php 
class AdminSetup extends Ci_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{

		$data['title'] = 'Setup';
		$data['files'] = $this->AdminSetup_model->getFiles();
		
		
		//$this->load->view('welcome_message');
		$this->load->view('admin/header', $data);
		$this->load->view('admin/setup_view', $data);

	}
}
