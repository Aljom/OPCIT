<?php 
class Manage_files extends Ci_Controller
{
	function __construct()
	{
		parent::__construct();
		
		$this->load->helper(array('form', 'url'));
	}
	public function index()
	{

		if(isset($_POST['uploadBtn'])){

		

			$MY_FILE = strtolower(pathinfo(basename($_FILES["file_upload"]["name"]),PATHINFO_EXTENSION));

			$values = array('owner'			=>$this->input->post("owner",true),
							'purpose'		=>$this->input->post("purpose",true),
							'department'	=>$this->input->post("department",true),
							'file_ext'		=>$MY_FILE,
							'file_name'		=>$_FILES["file_upload"]["name"]);



            				if(!file_exists('UPLOADS/'.$MY_FILE)){
            					mkdir('UPLOADS/'.$MY_FILE, 0777, true);

            					$config['upload_path']          = 'UPLOADS/'.$MY_FILE;
		                        $config['allowed_types']        = '*';
		                        $config['max_size']             = 10000;
			
			 					$this->load->library('upload', $config);
                                if ( ! $this->upload->do_upload('file_upload'))
                                {
                                        $error = array('error' => $this->upload->display_errors());
                                        // echo '<script>alert("'.$error.'")</script>';

                                        // $this->load->view('upload_form', $error);
                                }
                                else
                                {
                                        $data = array('upload_data' => $this->upload->data());
                                        // echo '<script>alert("'.$data.'")</script>';
                                        $this->Main_model->addFiles($values);
                                        // $this->load->view('upload_success', $data);
                                }
                           }
                           else
                           {
                           		$config['upload_path']          = 'UPLOADS/'.$MY_FILE;
		                        $config['allowed_types']        = '*';
		                        $config['max_size']             = 10000;
			
			 					$this->load->library('upload', $config);
                                if ( ! $this->upload->do_upload('file_upload'))
                                {
                                        $error = array('error' => $this->upload->display_errors());
                                        // echo '<script>alert("'.$error.'")</script>';

                                        // $this->load->view('upload_form', $error);
                                }
                                else
                                {
                                        $data = array('upload_data' => $this->upload->data());
                                        // echo '<script>alert("'.$data.'")</script>';
                                        $this->Main_model->addFiles($values);
                                        // $this->load->view('upload_success', $data);
                                }
                           }

			// $this->Main_model->addFiles($values);
			// if(!file_exists(base_url().'UPLOADS/'.$MY_FILE)){
			// 	mkdir('UPLOADS/'.$MY_FILE, 0777, true);

			// 	$target_dir = base_url()."UPLOADS/".$MY_FILE."/";
		 //      	$target_file = $target_dir . basename($_FILES["file_upload"]["name"]);

		       
		 //    	}
		 //    	else{
		 //    	$target_dir = base_url()."UPLOADS/".$MY_FILE."/";
		 //      	$target_file = $target_dir . basename($_FILES["file_upload"]["name"]);

		 //    	}
			
			/*if(!file_exists(base_url().'UPLOADS/'.$MY_FILE)) { // create folder if not exists.
		        mkdir('Uploads/'.$MY_FILE, 0777, true);

		      	$target_dir = base_url()."UPLOADS/".$MY_FILE."/";
		      	$target_file = $target_dir . basename($_FILES["file_upload"]["name"]);


		        if (move_uploaded_file($_FILES["file_upload"]["tmp_name"], $target_file)) {
		         	$this->Main_model->addFiles($values);
		       
		    	}

			
			}else{ 
				$target_dir = base_url()."UPLOADS/".$MY_FILE."/";
		      	$target_file = $target_dir . basename($_FILES["file_upload"]["name"]);


		        if (move_uploaded_file($_FILES["file_upload"]["tmp_name"], $target_file)) {
		         	$this->Main_model->addFiles($values);
		       
		    	}
			}*/
		}

		$data['title'] = 'Manage Files';
		$data['files'] = $this->Main_model->getFiles();
		$data['department'] = $this->Main_model->getDepartment();
		$this->load->view('admin/header', $data);
		$this->load->view('admin/manage_files_view',$data);
	}
}