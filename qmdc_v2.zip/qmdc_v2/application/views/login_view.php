<?php 

  $usertype =  $this->session->userdata('user_level');
  if(!($usertype==''))
  {
   header('location:'.base_url().'Dashboard');
  }


 ?>

 <!DOCTYPE html>
<html>
<head>
	<title><?php echo $title; ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/semantic/semantic.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/semantic/components/button.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/semantic/components/dropdonw.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/semantic/components/transition.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/semantic/components/modal.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/datatables/dataTables.semanticui.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/login.css">

	<body>


	<div class="container-fluid">
		<div class="row">
			<div class="col-7 left-side d-flex align-items-center">
				<img src="assets/img/title.png" class="img-fluid title-img">
			</div>
			<div class="col-5 right-side d-flex align-items-center">
				<div class="col-12 form-div">
					<div class="col-12 form-header">
						<center>
							<img src="assets/img/user-icon.png" class="user-icon">
							<h2>ACCOUNT LOGIN</h2>
						</center>
					</div>
					<div class="col-12 form-div-con">
						<form method="POST" action="">
							<?php if (isset($error)): ?>
							 <div class="alert alert-danger alert-dismissible fade show" id="divAlert">
								  <button type="button" class="close" id="close1" aria-label="Close">
								    <span aria-hidden="true">&times;</span>
								  </button>
								  <strong style="color: red;"><?php echo $error ?></strong>
							</div>
							<?php endif ?>
							<div class="ui left icon input" style="width:100%">
							  <input type="text" placeholder="Email Address" name="username" required="">
							  <i class="envelope icon"></i>
							</div>
							<div class="ui left icon input pass-input" style="width:100%;">
							  <input type="password" placeholder="Password" name="password" required="">
							  <i class="lock icon"></i>
							</div>
							<div class="forgot-div">
								<i><a href="#" class="forgot-btn">Forgot your password?</a></i>
							</div>
							<div class="login-btn-div text-center">
								<button class="ui right labeled icon button login-btn" name="btnLogin">
								  LOGIN
								  <i class="arrow right icon"></i>
								</button>
							</div><br><br>
						</form>
					</div>
				</div>
			</div>
		</div>
		
	</div>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
	<script type="text/javascript">
		$("#close1").click(function(){
			$("#divAlert").hide();
		})
	</script>
	<!-- <link rel="shortcut icon" type="text/css" href="<?php echo base_url();?>assets/images/makati_logo.png">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/color.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
	<script src="<?php echo base_url();?>assets/js/bootstrap.js" ></script>
	<script src="<?php echo base_url();?>assets/js/bootstrap.min.js" ></script>
</head>
<body>
<style type="text/css">
body{
background: -webkit-linear-gradient(55deg, rgb(94, 53, 177), rgb(30, 136, 229));
background: linear-gradient(55deg, rgb(94, 53, 177), rgb(30, 136, 229));
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;
height: 90vh;
}

</style>
<div class=" mtop-100">
	
	<div class="col-md-4 col-md-offset-4">
		<div class="col-md-12 bg-primary white-text pad-10 border" >
			<div class="mtop-10"><center><h4><span class="fa fa-user-circle-o"></span> LOGIN</center></h4></div>
		</div>
		<form method="POST">
			<div class="col-md-12 grey-1 pad-30 box-shadow" >

			<?php if (isset($error)): ?>
			 <div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				  <strong><?php echo $error ?></strong>
			</div>
			<?php endif ?>

				<div class="mtop-10">
					<label class="grey-text"><i class="fa fa-vcard-o"></i> USERNAME</label>
					<input type="text" class="form-control" name="username" required="">
				</div>
				<div class="mtop-10">
					<label class="grey-text"><i class="fa fa-key"></i> PASSWORD</label>
					<input type="password" class="form-control" name="password" required="">
				</div>
				<div class="mtop-10">
					<button class="btn btn-primary btn-block" name="btnLogin">Login <i class="fa fa-sign-in"></i></button>
				</div>
			</div>
		</form>
	</div>
</div> -->