 <script type="text/javascript">document.getElementById("navDash").setAttribute('class', 'active');</script>
 <div id="content">

      <nav class="navbar fixed-top navbar-light bg-light">
        <div class="container-fluid">
          <div class="navbar-header">
            <span class="nav-dash">DASHBOARD</span>
            <button type="button" id="sidebarCollapse" class="navbar-toggler navbar-btn">
              <i class="fa fa-bars" aria-hidden="true"></i>
            </button>
          </div>
        </div>
      </nav>
      <br><br>
  <div class="container-fluid dash-margin-top">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-12 top-col">
              <h2 class="main-title">Home</h2>
            </div>
            

            <hr width="100%">
          </div>
  </div>

</div>
</div>

