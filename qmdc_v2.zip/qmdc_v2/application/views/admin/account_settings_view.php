  <script type="text/javascript">
    document.getElementById("navAccount").setAttribute('class', 'active');
  </script>
 <div id="content">

      <nav class="navbar fixed-top navbar-light bg-light">
        <div class="container-fluid">
          <div class="navbar-header">
            <span class="nav-dash">DASHBOARD</span>
            <button type="button" id="sidebarCollapse" class="navbar-toggler navbar-btn">
              <i class="fa fa-bars" aria-hidden="true"></i>
            </button>
          </div>
        </div>
      </nav>
      <br><br>
  <div class="container-fluid dash-margin-top">
          <div class="row">
            <div class="col-12 top-col">
              <h2 class="main-title">Account Settings</h2>
            </div>

            <hr width="100%">
          </div>
         

          <div class="container-fluid no-padding">
            <div class="row">
              <div class="col-12 no-padding">

                <div class="row">

                  <div class="col-lg-8 col-md-6 col-12">
                  <!-- card -->
                <div class="card">
                      <div class="card-header cus-card-header" style="background:#fff">
                        <h3 style="font-weight: normal">Profile details</h3>               
                      </div>
                        
                      <div class="card-body">
                        
                        
                        <form action="#" method="post">
                
                        <div class="row"> 
                        
                        <div class="col-12">
                          <?php 
                            $userinfo = $this->Login_model->getUserbyID($_SESSION['id']);
                            $firstname = "";
                            foreach ($userinfo as $key) {
                              $firstname  = $key->first_name;
                              $lastname   = $key->last_name;
                              $fullname   = $key->first_name." ".$key->last_name; 
                              $email      = $key->email;
                              $department = $key->department;
                              $username   = $key->username;
                              $password   = $key->password;
                            }

                         ?>
                          
                          <div class="row">       

                            <div class="ui form col-lg-4">
                              <div class="field">
                                <label>First Name</label>
                                <input type="text" placeholder="First name" name="first_name" value="<?php echo $firstname; ?>"  required>
                              </div>
                            </div>

                            <div class="ui form col-lg-4">
                              <div class="field">
                                <label>Middle Name</label>
                                <input type="text" placeholder="Middle name" name="middle_name" value="<?php echo ''; ?>">
                              </div>
                            </div>

                            <div class="ui form col-lg-4">
                              <div class="field">
                                <label>Last Name</label>
                                <input type="text" placeholder="Last name" name="last_name" value="<?php echo $lastname; ?>"  required>
                              </div>
                            </div>

                            <div class="ui form col-lg-6">
                              <div class="field">
                                <label>Email Address</label>
                                <input type="email" placeholder="Email Adress" name="email_add" value="<?php echo $email; ?>" required>
                              </div>
                            </div>

                            <div class="ui form col-lg-6">
                              <div class="field">
                                <label>Username</label>
                                <input type="text" placeholder="Username" name="username" value="<?php echo $username; ?>" required>
                              </div>
                            </div>

                            <div class="ui form col-lg-6">
                              <div class="field">
                                <label>Password</label>
                                <input type="password" placeholder="Password" name="password" value="<?php echo $password; ?>" required>
                              </div>
                            </div>
                            
                          </div>
                          
                          <div class="row">
                            <div class="col-lg-12">
                              <br>
                            <button type="button" class="btn btn-primary">Edit profile</button>
                            </div>
                          </div>
                        
                        </div>
                        
                        </div>                
                        
                        </form>
                      </div>
                        
                </div>  
                <!-- end card-body -->
                </div>
                
                <div class="col-lg-4 col-md-6 col-12">
                  <!-- card -->
                <div class="card">
                      <div class="card-header cus-card-header" style="background:#fff">
                        <h3 style="font-weight: normal">Profile Picture</h3>               
                      </div>
                        
                      <div class="card-body">
                        
                        <form action="#" method="post" enctype="multipart/form-data">
                
                        <div class="row"> 
    
                        <div class="col-12">
                          <center>
                            <img class="ui medium circular image img-fluid profile-pic" src="<?php echo base_url();?>assets/img/face1.jpg">
                          </center>
                        
                          <a class="btn btn-primary upload-new-profile-img-btn" data-toggle="modal" data-target="#changeProfilePicModal">Change profile picture</a>
                        </div>
                        </div>                
                        
                        </form>                   
                        </div>
                </div>  
                <!-- end card-body -->

                </div>
                  
                </div>
              
              </div>
            </div>
          </div>
  </div>

</div>
</div>
 <!-- Modal -->
  <div class="modal fade" id="changeProfilePicModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog h-100 d-flex flex-column justify-content-center my-0" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title" id="exampleModalLabel">Change Profile Picture</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

        
            
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button class="btn btn-primary" name="btnAdd">Upload</button>
           
        </div>
       
      </div>
    </div>
  </div>

<!--Scripts-->
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/datatables/dataTables.semanticui.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/bootstrap-colorpicker-master/dist/js/bootstrap-colorpicker.min.js"></script>

  <script type="text/javascript" src="<?php echo base_url();?>assets/js/tablesort.js"></script>
  <script type="text/javascript">
    

    $('table').DataTable({
      searching: true,
      ordering: true
    });

    $('table').tablesort();

    $('.action-btn').dropdown({
        action: 'hide',
        on: 'hover'
    });

    $('.colorpickerinput').colorpicker();

    $('select.dropdown').dropdown();

  </script>

