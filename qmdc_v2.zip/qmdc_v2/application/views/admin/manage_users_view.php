  <script type="text/javascript">
  document.getElementById("navUsers").setAttribute('class', 'active');
</script>
 <div id="content">

      <nav class="navbar fixed-top navbar-light bg-light">
        <div class="container-fluid">
          <div class="navbar-header">
            <span class="nav-dash">DASHBOARD</span>
            <button type="button" id="sidebarCollapse" class="navbar-toggler navbar-btn">
              <i class="fa fa-bars" aria-hidden="true"></i>
            </button>
          </div>
        </div>
      </nav>
      <br><br>
  <div class="container-fluid dash-margin-top">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-12 top-col">
              <h2 class="main-title">Manage Users</h2>
            </div>
            <div class="col-lg-6 col-md-6 col-12 top-col" align="right">
              <button class="ui right labeled icon button blue upload-btn" data-toggle="modal" data-target="#createFolderModal">
                Add New
                <i class="plus icon"></i>
              </button>
            </div>

            <hr width="100%">
          </div>
         

          <div class="container-fluid">
        <div class="row">
          <div class="col-12 no-padding">
            <table class="ui compact selectable sortable celled blue table" cellspacing="0" width="100%"  style="margin: 0 auto;">
              <thead>
                <tr>
                  <th>No.</th>
                  <th class="">Name</th>
                  <th class="">Role</th>
                  <th class="">Department</th>
                  <th class="">Action</th>
                </tr>
              </thead>
              <tbody>
               <?php 
               $ctr=1;
               foreach ($users as $key): 
                $fullname = $key->first_name." ".$key->last_name
                ?>
              <tr>
                    <td>
                      <?php echo $ctr ?>
                    </td>
                    <td><?php echo $fullname ?></td>
                    <td><?php echo $key->user_level ?></td>
                    <td><?php echo $key->department ?></td>
                    <td class="action-th">
                      <center>
                        <div class="ui blue action-btn floating dropdown button">
                      <div class="text">Action</div>
                      <i class="dropdown icon" style="margin-left: 20px;margin-right: 0px;"></i>
                      <div class="menu">
                        <div class="item" data-target="#editUser<?php echo $key->id?>" data-toggle="modal"><i class="edit icon"></i> Edit</div>
                        <div class="item" data-target="#deleteUser<?php echo $key->id?>" data-toggle="modal"><i class="delete icon" ></i> Remove</div>
                      </div>
                    </div>
                  </center>
                    </td>
                </tr>
                <!-- Edit Modal -->
  <div class="modal fade" id="editUser<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog h-100 d-flex flex-column justify-content-center my-0" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title" id="exampleModalLabel">Edit User</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <form method="POST" action="">
            <div class="ui form">
              <div class="field">
                <label>First Name</label>
                <input type="text" placeholder="First name" name="first_name2" value="<?php echo $key->first_name?>" required>
              </div>
            </div>
            <div class="ui form">
              <div class="field">
                <label>Last Name</label>
                <input type="text" placeholder="Last Name" name="last_name2" value="<?php echo $key->last_name?>" required>
              </div>
            </div>
            <div class="ui form">
              <div class="field">
                <label>Department</label>
                  
                    <select class="form_input" name="department2" id="department2">
                      <option style="display: none;"><?php echo $key->department?></option>
                       <?php
                          foreach ($department as $dept){
                       ?>        
                        <option value="<?php echo $dept->department_name ?>"><?php echo $dept->department_name ?></option>
                      <?php } ?>
                    </select>
                
                </div>
              </div>
              <div class="ui form">
              <div class="field">
                <label>User Level</label>
                  <select class= "form_input" name="user_level2" >
                    <option style="display: none;"><?php echo $key->user_level?></option>
                    <option>Administrator</option>
                    <option>CBAT</option>
                    <option>GUEST</option>
                  </select>
                </div>
              </div>
               <div class="ui form">
              <div class="field">
                <label>Email</label>
                <input type="text" placeholder="Email" name="email2" value="<?php echo $key->email?>" required>
              </div>
            </div>
             <div class="ui form">
              <div class="field">
                <label>User Name</label>
                <input type="text" placeholder="User Name" name="username2" value="<?php echo $key->username?>" required>
              </div>
            </div>
             <div class="ui form">
              <div class="field">
                <label>Password</label>
                <input type="password" placeholder="Password" name="password2" value="<?php echo $key->password?>" required>
              </div>
            </div>
          
          <input type="hidden" name="user_id2" value="<?php echo $key->id?>">
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" name="btnSave">Save</button>
           </form>
        </div>
       
      </div>
    </div>
  </div>

                <!-- DeleteModal -->
  <div class="modal fade" id="deleteUser<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog h-100 d-flex flex-column justify-content-center my-0" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title" id="exampleModalLabel">Delete User</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <form method="POST" action="">
            <div class="ui form">
              <div class="field">
                <label></label>
               <div class="text">Are you Sure you want to remove <b><?php echo $fullname;?></b>?</div>
               <input type="hidden" name="user_id" value="<?php echo $key->id?>">
              </div>
            </div>      
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
          <button type="submit"  class="btn btn-primary" name="deleteUser">Yes</button>
           </form>
        </div>
       
      </div>
    </div>
  </div>
              <?php $ctr++; endforeach ?>
            </tbody>
            </table>
          </div>
        </div>
      </div>
  </div>

</div>
</div>
 <!-- Modal -->
  <div class="modal fade" id="createFolderModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog h-100 d-flex flex-column justify-content-center my-0" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title" id="exampleModalLabel">Add New User</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <form method="POST" action="">
            <div class="ui form">
              <div class="field">
                <label>First Name</label>
                <input type="text" placeholder="First name" name="first_name" required>
              </div>
            </div>
            <div class="ui form">
              <div class="field">
                <label>Last Name</label>
                <input type="text" placeholder="Last Name" name="last_name" required>
              </div>
            </div>
            <div class="ui form">
              <div class="field">
                <label>Department</label>
                  <select class="ui dropdown" name="department" >
                     <?php
                        foreach ($department as $dept){
                     ?>        
                      <option value="<?php echo $dept->department_name ?>"><?php echo $dept->department_name ?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
              <div class="ui form">
              <div class="field">
                <label>User Level</label>
                  <select class="ui dropdown" name="user_level">
                     <?php
                        foreach ($department as $dept){
                     ?>        
                      <option value="<?php echo $dept->department_name ?>"><?php echo $dept->department_name ?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
               <div class="ui form">
              <div class="field">
                <label>Email</label>
                <input type="text" placeholder="Email" name="email" required>
              </div>
            </div>
             <div class="ui form">
              <div class="field">
                <label>User Name</label>
                <input type="text" placeholder="User Name" name="username" required>
              </div>
            </div>
             <div class="ui form">
              <div class="field">
                <label>Password</label>
                <input type="password" placeholder="Password" name="password" required>
              </div>
            </div>
          
          
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" name="btnAdd">Add</button>
           </form>
        </div>
       
      </div>
    </div>
  </div>

<!--Scripts-->
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/popper.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/semantic/semantic.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/custom-scrollbar/mCustomScrollbar.concat.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/datatables/dataTables.semanticui.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/bootstrap-colorpicker-master/dist/js/bootstrap-colorpicker.min.js"></script>

  <script type="text/javascript" src="<?php echo base_url();?>assets/js/tablesort.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/sidebar.js"></script>
  <script type="text/javascript">
    

    $('table').DataTable({
      searching: true,
      ordering: true
    });

    $('table').tablesort();

    $('.action-btn').dropdown({
        action: 'hide',
        on: 'hover'
    });

    $('.colorpickerinput').colorpicker();

    $('select.dropdown').dropdown();


    

  </script>

