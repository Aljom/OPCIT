<?php 

  $usertype =  $this->session->userdata('user_level');
  if($usertype=='')
  {
    header('location:'.base_url());
  }
   date_default_timezone_set('Asia/Manila');


   
 ?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title; ?></title>
  <!--Bootstrap-->

     <!--Bootstrap-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css">
    <!--Semantic UI-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/semantic/semantic.min.css">
    <!--Scroll bar plugin-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/custom-scrollbar/mCustomScrollbar.min.css">
    <!--Font-Awesome-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/datatables/dataTables.semanticui.min.css">
    <!-- DateRangePicker -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/bootstrap-daterangepicker-master/daterangepicker.css">
    <!-- SweetAlert -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/sweetalert/sweetalert2.min.css">
    <!-- Loading -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/loading.css">
    <!--Custom CSS-->
    <link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/sidebar.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/custom.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/dropzone.css">

   <!--Scripts-->
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/popper.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/semantic/semantic.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/custom-scrollbar/mCustomScrollbar.concat.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/sweetalert/sweetalert2.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/sidebar.js"></script>
  <!--Loader -->
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/loading.js"></script>
  
</head>
	<body>

	<?php 
        $userinfo = $this->Login_model->getUserbyID($_SESSION['id']);
        $firstname = "";
        foreach ($userinfo as $key) {
          $firstname = $key->first_name;
          $lastname = $key->last_name;
          $fullname = $key->first_name." ".$key->last_name; 
        }

     ?>
    <div class="wrapper">
    <!-- Sidebar Holder -->
    <nav id="sidebar">
      <div class="sidebar-header">
        <center>
          <img class="ui medium circular image img-fluid account-img" src="<?php echo base_url();?>assets/img/face1.jpg">
          <div class="user-name"><?php echo ucwords($fullname)?></div>
          <div class="user-position"><?php echo ucwords($_SESSION['user_level']);?></div>
        </center>
      </div>

      <ul class="list-unstyled components">

        <li id="navDash">
          <a href="<?php echo base_url() ?>Dashboard"><i class="fa fa-home nav-icon-space" aria-hidden="true"></i>Home</a>
        </li>
        <li id="navSetup">
          <a href="#mngFoldersSubMenu" id="mngFolders_toggle" class="nav_with_sub" data-toggle="collapse" aria-expanded="false">
            <i class="fa fa-folder-open nav-icon-space2"></i>
            Manage Folders</a>
            <ul class="collapse list-unstyled" id="mngFoldersSubMenu">
              <li id=""><a href="preview-folders.php" class="nav-sub-menu">Preview Folders</a></li>
              <li id=""><a href="<?php echo base_url() ?>AdminSetup" class="nav-sub-menu">Setup Folders</a></li>
            </ul>
        </li>
        <li id="navUsers">
          <a href="<?php echo base_url() ?>Manage_users"><i class="fa fa-users nav-icon-space" aria-hidden="true"></i>Manage Users</a>
        </li>
        <li id="navFiles">
          <a href="<?php echo base_url() ?>Manage_files"><i class="fa fa-files-o nav-icon-space" aria-hidden="true"></i>Manage Files</a>
        </li>
        <li id="navDept">
          <a href="<?php echo base_url() ?>Manage_department"><i class="fa fa-building nav-icon-space" aria-hidden="true"></i>Manage Department</a>
        </li>
        <li>
          <a href="#accountSubMenu" id="acount_toggle" class="nav_with_sub" data-toggle="collapse" aria-expanded="false"><i class="fa fa-user nav-icon-space"></i>
                        Account</a>
            <ul class="collapse list-unstyled" id="accountSubMenu">
              <li><a href="<?php echo base_url() ?>Account_settings" class="nav-sub-menu">Settings</a></li>
              <li><a href="<?php echo base_url() ?>Logout" class="nav-sub-menu">Logout</a></li>
            </ul>
        </li>
                    
      </ul>

    </nav>

  <div class="se-pre-con"></div>
  