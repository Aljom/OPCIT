 <meta name="csrf-token" content="XYZ123"> 
 <!-- Dropzone -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/dropzone.css">
<!--SweetAlert2--
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/plugins/sweetalert/sweetalert2.min.css"-->

<script type="text/javascript">
  document.getElementById("navFiles").setAttribute('class', 'active');
</script>
 <div id="content">

      <nav class="navbar fixed-top navbar-light bg-light">
        <div class="container-fluid">
          <div class="navbar-header">
            <span class="nav-dash">DASHBOARD</span>
            <button type="button" id="sidebarCollapse" class="navbar-toggler navbar-btn">
              <i class="fa fa-bars" aria-hidden="true"></i>
            </button>
          </div>
        </div>
      </nav>
      <br><br>

       <?php if (isset($success)): ?>
               <div class="alert alert-danger alert-dismissible fade show" id="divAlert" style="width: 100%;">
                  <button type="button" class="close" id="close1" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <strong style="color: green;"><?php echo $success ?></strong>
              </div>
              <?php endif ?>

       <div class="container-fluid header-con">
        
          <div class="row">
            <div class="col-lg-4 col-md-4 col-12 top-col">
              <h2 class="main-title"><?php echo $title ?></h2>
            </div>
            <div class="col-lg-5 col-md-4 col-12 top-col d-flex align-items-center">
              <div class="header-line"></div>
            </div>
            <div class="col-lg-3 col-md-4 col-12 top-col">
              <button class="ui right labeled icon button blue upload-btn" data-toggle="modal" data-target="#uploadModal">
                Upload File
                <i class="upload icon"></i>
              </button>
            </div>
            <hr width="100%">
          </div>

           <div class="row">
          <div class="col-12 no-padding">
            <table class="ui compact selectable sortable celled blue table" cellspacing="0" width="100%"  style="margin: 0 auto;">
              <thead>
                <tr>
                  <th class="">File Name</th>
                  <th class="">Owner</th>
                  <th class="">Purpose</th>
                  <th class="">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($files as $key): 
                ?>
                <tr>
                  <td>
                    <?php
                    if(!file_exists('assets/img/icons/'.$key->file_ext.'.svg')){
                      $ext = "question";
                    }
                    else{
                      $ext = $key->file_ext;
                    }
                     echo '<img class="img-fluid file-logo-img" src="'.base_url().'assets/img/icons/'.$ext.'.svg">
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      '.$key->file_name;
                      ?>
                  </td>
                  <td><?php echo $key->owner ?></td>
                  <td><?php echo $key->purpose ?></td>
                  <td class="action-th">
                      <center>
                        <div class="ui blue action-btn floating dropdown button">
                      <div class="text">Action</div>
                      <i class="dropdown icon" style="margin-left: 20px;margin-right: 0px;"></i>
                      <div class="menu">
                        <div class="item"><i class="eye icon"></i> View</div>
                        <div class="item"><a href="UPLOADS/<?php echo $key->file_ext?>/<?php echo $key->file_name ?>" target="_blank" ><i class="download arrow icon"></i> Download File</a></div>
                        <div class="item"><i class="edit icon"></i> Edit</div>
                        <div class="item"><i class="delete icon"></i> Remove</div>
                      </div>
                    </div>
                  </center>
                    </td>
                  
                </tr>
              <?php endforeach ?>
               
              </tbody>
            </table>
          
      </div>

      <!-- Modal -->
  <div class="modal fade" id="uploadModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog h-100 d-flex flex-column justify-content-center my-0" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title" id="exampleModalLabel">Upload Files</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <form id="upload-widget" action="<?php echo base_url();?>upload2.php" class="dropzone"  enctype="multipart/form-data"  >
            <div class="fallback">
                <input name="file_upload" id="file_upload" type="file" />  
            </div>
          </form>
         <!--  <form id="upload-widget" method="POST" action="upload2.php" class="dropzone" enctype="multipart/form-data" >
             <div class="fallback">
                <input name="file_upload" id="file_upload" type="file" />  
            </div>
          </form> -->
       <!--    <form id="upload-widget" method="post" class="dropzone" ><!-- action="upload2.php" --
             <div class="fallback">
                <input name="file" type="file" />
            </div>
          </form>

          <form method="POST" action="" enctype="multipart/form-data">
            <div class="ui form">
              <div class="field">
                <label>Select File</label>
                <!-- <input type="file" id="file" placeholder="Select File" name="file_upload" required> --
                <div class="dropzone" id="upload-widget">
                  <div class="dropzone-previews"></div>
                </div>
                 
              </div>
            </div>

             <div class="ui form">
              <div class="field">
                <label>Owner</label>
                <input type="text" placeholder="Owner" name="owner" required>
              </div>
            </div>
              
            <div class="ui form">
              <div class="field">
                <label>Department</label>
                <select class="ui dropdown" name="department" required >
                  <option value="">Select Department</option>
                  <?php
                  foreach ($department as $dept){
                   ?>
                  
                  
                    <option value="<?php echo $dept->department_name ?>"><?php echo $dept->department_name ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>

            <div class="ui form">
              <div class="field">
                <label>Purpose</label>
                <textarea name="purpose" required></textarea>
              </div>
            </div>
              
         
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" name="uploadBtn">Upload File</button>
           </form> -->
          <form method="POST">
           <div class="ui form">
              <div class="field">
                <label>Owner</label>
                <input type="text" placeholder="Owner" name="owner" id="owner" required>
              </div>
            </div>
              
            <div class="ui form">
              <div class="field">
                <label>Department</label>
                <select class="ui dropdown" name="department" id="department" required >
                  <option value="">Select Department</option>
                  <?php
                  foreach ($department as $dept){
                   ?>
                  
                  
                    <option value="<?php echo $dept->department_name ?>"><?php echo $dept->department_name ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>

            <div class="ui form">
              <div class="field">
                <label>Purpose</label>
                <textarea name="purpose" id="purpose" required></textarea>
              </div>
            </div>
              
         
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" name="uploadBtn" id="uploadBtn">Upload File</button>
          </form>
        </div>
      
      </div>
    </div>
  </div>





      <!--Scripts-->
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<!--   <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-1.2.1.min.js"></script> -->
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/moment.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/popper.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/semantic/semantic.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/custom-scrollbar/mCustomScrollbar.concat.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/datatables/dataTables.semanticui.min.js"></script>

  <script type="text/javascript" src="<?php echo base_url();?>assets/js/tablesort.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/bootstrap-daterangepicker-master/daterangepicker.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/sweetalert/sweetalert2.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/sidebar.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/dropzone.min.js"></script>
  <script type="text/javascript">
  $('.filter-drop').dropdown({
      allowAdditions: true,
      debug: true,
      performance: true,
      onChange: function(value, text, $selectedItem) {
        //alert(value);
      if( value.includes("all") || text.includes("all") ){
        
        //$("#purpose_select").dropdown('restore default text');
        //$("#purpose_select").dropdown('refresh');
        $(this).dropdown('toggle');
        //$("#purpose_select").dropdown('remove active');
        $(this).dropdown('clear');
        //$("#purpose_select").dropdown('restore default text');
      }
      else{

      }
      }
  });


  $('table').DataTable({
    searching: true,
    ordering: true
  });

  $('.action-btn').dropdown({
      action: 'hide',
      on: 'hover'
  });

  $('table').tablesort();

  $('#upload_modal').modal();
  

  $('select.dropdown').dropdown();

   Dropzone.options.uploadWidget = {
  //   url: 'upload2.php',
  paramName: 'file',
  //uploadMultiple: true,
  parallelUploads: 5,
  autoProcessQueue: false,
  addRemoveLinks: true,
  dictCancelUpload: 'Uploading File',
  renameFile: true,
  maxFilesize: 1000, // MB
  maxFiles: 5,
  dictDefaultMessage: 'Drag a file here, or click to select one',
  headers: {
    'x-csrf-token': document.querySelectorAll('meta[name=csrf-token]')[0].getAttributeNode('content').value,
  },
  // acceptedFiles: '*',
  init: function() {
    this.on('success', function( file, resp ){
      console.log( file );
      console.log( resp );
    });
     var submitButton = document.querySelector("#uploadBtn")
            myDropzone = this; // closure

        submitButton.addEventListener("click", function(e) {
          
          e.preventDefault();
          e.stopPropagation();
          myDropzone.processQueue(); // Tell Dropzone to process all queued files.

              

          //alert( $("#file_upload").val());
          //location.reload();
        
          
              
        });

        //send all the form data along with the files:
        this.on("sending", function(data, xhr, formData) {
          
          formData.append("owner", $("#owner").val());
          formData.append("purpose", $("#purpose").val());
          formData.append("department", $("#department").val());

          swal({
                              type: 'success',
                              title: 'Successfully Uploaded',
                              text: '',
                              confirmButtonClass: "sweetalert-btn"
                          }).then(function(){
                            location.reload();
                          });

        });
        
  
  },

};



    
</script>