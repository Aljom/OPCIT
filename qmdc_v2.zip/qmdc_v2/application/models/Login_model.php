<?php 
class Login_model extends CI_MODEL
{
	
	function __construct()
	{
		$this->load->database();
	}

	public function checkLogin($username,$password)
	{
		$query = $this->db->select()->from('user_login')->where('username', $username)->where('password', $password)->get();
		return $query->result();
	}

	public function getUserbyID($ID)
	{
		$query = $this->db->select()->from('user_login')->where('id', $ID)->get();
		return $query->result();
	}
}

