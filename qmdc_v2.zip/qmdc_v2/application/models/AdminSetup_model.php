<?php 
class AdminSetup_model extends CI_MODEL
{
	
	function __construct()
	{
		$this->load->database();
	}

	public function getFiles()
	{
		$query = $this->db->select()->from('tbl_file_upload')->get();
		return $query->result();
		//return "<script>alert(".$query.")</script>";
	}
}

