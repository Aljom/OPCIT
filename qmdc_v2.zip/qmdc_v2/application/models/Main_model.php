<?php 
class Main_model extends CI_MODEL
{
	
	function __construct()
	{
		$this->load->database();
	}

/*	http://www.network-science.de/ascii/  (BANNER3 FONT)
##     ##  ######  ######## ########   ######  
##     ## ##    ## ##       ##     ## ##    ## 
##     ## ##       ##       ##     ## ##       
##     ##  ######  ######   ########   ######  
##     ##       ## ##       ##   ##         ## 
##     ## ##    ## ##       ##    ##  ##    ## 
 #######   ######  ######## ##     ##  ######  */
	public function getUsers()
	{
		$query = $this->db->select()->from('user_login')->get();
		return $query->result();
		//return "<script>alert(".$query.")</script>";
	}
	public function addNewUsers($values){
		$query = $this->db->insert('user_login', $values);
		if($query){
			echo "<script>alert('Succesfully Added!')</script>";
		}
	}
	public function updateUser($id,$values){
		$query = $this->db->where('id',$id)->update('user_login',$values);
		if($query){
			echo "<script>alert('Succesfully Updated!')</script>";
		}

	}
	public function deleteUser($value){
		$query = $this->db->where('id',$value)->delete('user_login');

		if($query){
			echo "<script>alert('Succesfully Removed!');</script>";
		}
	}
########  ######## ########     ###    ########  ######## ##     ## ######## ##    ## ######## 
##     ## ##       ##     ##   ## ##   ##     ##    ##    ###   ### ##       ###   ##    ##    
##     ## ##       ##     ##  ##   ##  ##     ##    ##    #### #### ##       ####  ##    ##    
##     ## ######   ########  ##     ## ########     ##    ## ### ## ######   ## ## ##    ##    
##     ## ##       ##        ######### ##   ##      ##    ##     ## ##       ##  ####    ##    
##     ## ##       ##        ##     ## ##    ##     ##    ##     ## ##       ##   ###    ##    
########  ######## ##        ##     ## ##     ##    ##    ##     ## ######## ##    ##    ## 

	public function getDepartment(){
		$query = $this->db->select()->from('tbl_department')->get();
		return $query->result();
	}
	public function addNewDepartment($values){
		$query = $this->db->insert('tbl_department', $values);
		if($query){
			echo "<script>alert('Succesfully Added!')</script>";
		}

	}
	public function updateDepartment($id,$values){
		$query = $this->db->where('id',$id)->update('tbl_department',$values);
		if($query){
			echo "<script>alert('Succesfully Updated!')</script>";
		}
	}

	public function deleteDept($value){
		$query = $this->db->where('id',$value)->delete('tbl_department');

		if($query){
			echo "<script>alert('Succesfully Removed!');</script>";
		}
	}
######## #### ##       ########  ######  
##        ##  ##       ##       ##    ## 
##        ##  ##       ##       ##       
######    ##  ##       ######    ######  
##        ##  ##       ##             ## 
##        ##  ##       ##       ##    ## 
##       #### ######## ########  ######  

	public function getFiles(){
		$query = $this->db->select()->from('tbl_file_upload')->get();
		return $query->result();
	}
	public function addFiles($values){
		$query = $this->db->insert('tbl_file_upload', $values);
		if($query){
			echo "<script>alert('Succesfully Added!')</script>";
		}
	}
}

