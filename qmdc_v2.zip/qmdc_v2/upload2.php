<?php
$conn = mysqli_connect("localhost","root","","qmdc");
$ut="utf8";
mysqli_set_charset($conn,$ut);

if(!$conn){
	echo mysqli_error();
}
$owner = $_REQUEST['owner'];
$purpose = $_REQUEST['purpose'];
$department = $_REQUEST['department'];
$ds          = DIRECTORY_SEPARATOR;  //1
 
//$storeFolder = 'UPLOADS';   //2
 
if (!empty($_FILES)) {
     
    $tempFile = $_FILES['file']['tmp_name'];          //3             
      
    // $targetPath = dirname( __FILE__ ) . $ds. $storeFolder . $ds;  //4
     
    // $targetFile =  $targetPath. $_FILES['file']['name'];  //5
 
    $MY_FILE = strtolower(pathinfo(basename($_FILES["file"]["name"]),PATHINFO_EXTENSION));

    $MY_FILE_NAME = $_FILES["file"]["name"];

    if(!file_exists('UPLOADS/'.$MY_FILE)){
    	 mkdir('UPLOADS/'.$MY_FILE, 0777, true);

    	$targetPath =  'UPLOADS/'.$MY_FILE . $ds;

    	$targetFile =  $targetPath. $_FILES['file']['name'];

    	 if(move_uploaded_file($tempFile,$targetFile)) {
	    	$sql = "INSERT INTO tbl_file_upload (owner,purpose,department,file_ext,file_name) VALUES('".$owner."','".$purpose."','".$department."','".$MY_FILE."','".$MY_FILE_NAME."')";
	    	$query = mysqli_query($conn,$sql);
    	}
    }
    else{

    	$storeFolder = 'UPLOADS/'.$MY_FILE;

    	$targetPath =  $storeFolder . $ds;

    	$targetFile =  $targetPath. $_FILES['file']['name'];

    	 if(move_uploaded_file($tempFile,$targetFile)) {
	    	$sql = "INSERT INTO tbl_file_upload (owner,purpose,department,file_ext,file_name) VALUES('".$owner."','".$purpose."','".$department."','".$MY_FILE."','".$MY_FILE_NAME."')";
	    	$query = mysqli_query($conn,$sql);
    	}

    }

   
     
}

// function InsertingData($owner,$purpose,$MY_FILE,$targetFile){

// 		$sql = "INSERT INTO tbl_file_upload (owner,purpose,file_ext,file_name) VALUES('".$owner."','".$purpose."','".$MY_FILE."','".$targetFile."')";
//     	$query = mysqli_query($conn,$sql);

// }
?>   