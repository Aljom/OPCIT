-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 29, 2018 at 09:54 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qmdc`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectAllUser` ()  SQL SECURITY INVOKER
SELECT * FROM user_login$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

CREATE TABLE `tbl_department` (
  `id` int(5) NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_department`
--

INSERT INTO `tbl_department` (`id`, `department_name`, `description`) VALUES
(1, 'IT Department', 'Can add, edit, delete everything'),
(2, 'CBAT Department', 'Can search, add, edit, delete files only.'),
(3, 'CCS Department', 'Can search and download files only.'),
(4, 'COE Deparment', 'College of Education'),
(5, 'General Department', 'Administrators');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_file_upload`
--

CREATE TABLE `tbl_file_upload` (
  `id` int(5) NOT NULL,
  `owner` varchar(100) NOT NULL,
  `purpose` varchar(200) NOT NULL,
  `department` varchar(100) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `file_ext` varchar(100) NOT NULL,
  `file_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_file_upload`
--

INSERT INTO `tbl_file_upload` (`id`, `owner`, `purpose`, `department`, `date_added`, `file_ext`, `file_name`) VALUES
(22, 'qwe', 'qwqw', 'IT Department', '2018-01-25 02:09:50', 'png', '14.png'),
(23, 'haha', 'haha', 'IT Department', '2018-01-25 02:10:41', 'png', '13.png'),
(24, 'carl', 'qwe', 'COE Department', '2018-01-25 02:11:37', 'png', 'carl.png'),
(25, 'this is jpg', 'asd', 'CCS Department', '2018-01-25 02:12:04', 'jpg', 'blade.jpg'),
(26, 'cacc', 'cccc', 'IT Department', '2018-01-25 02:14:35', 'png', 'CUES (5).png'),
(27, 'pdf', 'pdf', 'COE Department', '2018-01-25 02:19:18', 'pdf', 'letter request-jaysel 1 1.pdf'),
(28, 'ada', 'asda', 'COE Department', '2018-01-25 02:25:12', 'png', '1.png'),
(29, 'xlx', 'xasd', 'COE Department', '2018-01-25 02:25:53', 'xlsx', 'manpower_databank.xlsx'),
(30, 'try', 'ytry', 'IT Department', '2018-01-25 02:52:51', 'mp3', 'Moira_Dela_Torre_sings_Torete_LIVE_on_Wish_1075_Bus[Mp3Converter.net].mp3'),
(31, '/''', 'l;', 'COE Department', '2018-01-25 02:55:52', 'gz', 'molips_8-18-2016 (3).sql.gz'),
(32, 'zxc', 'zxcxz', 'IT Department', '2018-01-25 02:56:14', 'php', 'report_hdmf_list.php'),
(33, 'qwewqe', 'qwe', 'COE Department', '2018-01-25 04:37:39', 'sql', 'mysahod.sql'),
(34, 'qwe', 'qweqeq', 'COE Department', '2018-01-25 04:40:43', 'sql', 'timekeeping.sql'),
(35, 'asda', 'asda', 'COE Department', '2018-01-25 04:42:06', 'bin', 'file_table-file.bin'),
(36, 'qwewqe', 'qwewqe', 'COE Department', '2018-01-25 04:43:06', 'url', 'Remove the footer link.URL');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(5) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `department` varchar(100) NOT NULL,
  `user_level` varchar(50) DEFAULT NULL COMMENT '1 = admin/ director , 2 = cbat , 3 = staff, 4 = accreditor',
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `first_name`, `middle_name`, `last_name`, `email`, `username`, `password`, `department`, `user_level`, `createdDate`) VALUES
(1, 'Jomarie', 'Alarcon', 'Lumactod', 'jlumactod1@gmail.com', 'jlumactod', '123', 'IT Department', 'Administrator', '2018-01-29 07:04:07'),
(5, 'Jefferson', '', 'Casitas', 'jaycasitas1@gmail.com', 'jep123', '123456', 'CCS Department', 'Administrator', '2018-01-29 07:11:57'),
(6, 'Jay', '', 'Quiambao', 'jaycute@gmail.com', 'jay', '123', 'COE Deparment', 'CBAT', '2018-01-29 07:12:26'),
(7, 'Jomiel', '', 'Andrade', 'jomielandrade@gmail.com', 'jomiel', '123', 'IT Department', 'Administrator', '2018-01-29 07:12:47'),
(8, 'Gilbert ', '', 'Marfil', 'gilbert@gmail.com', 'jay', '123', '', 'GUEST', '2018-01-29 07:11:01'),
(9, 'Ron', '', 'Balbin', 'gilbert@gmail.com', '123', '123', 'CCS Department', 'CBAT', '2018-01-29 07:13:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_department`
--
ALTER TABLE `tbl_department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_file_upload`
--
ALTER TABLE `tbl_file_upload`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_department`
--
ALTER TABLE `tbl_department`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_file_upload`
--
ALTER TABLE `tbl_file_upload`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
