-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 01, 2018 at 10:11 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qmdc`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectAllUser` ()  SQL SECURITY INVOKER
SELECT * FROM user_login$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

CREATE TABLE `tbl_department` (
  `id` int(5) NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_department`
--

INSERT INTO `tbl_department` (`id`, `department_name`, `description`) VALUES
(1, 'IT Department', 'Can add, edit, delete everything'),
(2, 'CBAT Department', 'Can search, add, edit, delete files only.'),
(3, 'CCS Department', 'College of Computer Science'),
(5, 'General Department', 'Administrators');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_file_upload`
--

CREATE TABLE `tbl_file_upload` (
  `id` int(5) NOT NULL,
  `owner` varchar(100) NOT NULL,
  `purpose` varchar(200) NOT NULL,
  `department` varchar(100) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `file_ext` varchar(100) NOT NULL,
  `file_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_file_upload`
--

INSERT INTO `tbl_file_upload` (`id`, `owner`, `purpose`, `department`, `date_added`, `file_ext`, `file_name`) VALUES
(127, 'sasa', 'sasa', 'CBAT Department', '2018-02-01 09:08:44', 'jpg', '01.mise-min.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(5) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `department` varchar(100) NOT NULL,
  `user_level` varchar(50) DEFAULT NULL COMMENT '1 = admin/ director , 2 = cbat , 3 = staff, 4 = accreditor',
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `first_name`, `middle_name`, `last_name`, `email`, `username`, `password`, `department`, `user_level`, `createdDate`) VALUES
(1, 'Jomarie', 'Alarcon', 'Lumactod', 'jlumactod1@gmail.com', 'jlumactod', '123', 'General Department', 'Administrator', '2018-02-01 07:49:09'),
(16, 'Jomiel', '', 'Andrade', 'jomielandrade@gmail.com', 'bimby', '123', 'COE Deparment', 'CBAT', '2018-02-01 07:32:09'),
(17, 'Ron', '', 'Balbin', 'test@test.com', 'qwe', '123', 'IT Department', 'Administrator', '2018-02-01 07:33:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_department`
--
ALTER TABLE `tbl_department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_file_upload`
--
ALTER TABLE `tbl_file_upload`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_department`
--
ALTER TABLE `tbl_department`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_file_upload`
--
ALTER TABLE `tbl_file_upload`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;
--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
