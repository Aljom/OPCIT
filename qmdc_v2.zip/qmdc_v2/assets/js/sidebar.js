$(document).ready(function () {
    $("#sidebar").mCustomScrollbar({
        theme: "minimal"
    });

    $('#sidebarCollapse').on('click', function () {
        $('#sidebar, #content').toggleClass('active');
        $('.collapse.in').toggleClass('in');
        $('a[aria-expanded=true]').attr('aria-expanded', 'false');
    });

    $('#accountSubMenu').on('show.bs.collapse', function () {
        $("#acount_toggle").addClass("sidebar-left-line");
    });

    $('#accountSubMenu').on('hidden.bs.collapse', function () {
        $("#acount_toggle").removeClass("sidebar-left-line");
    });

    $('#mngFoldersSubMenu').on('show.bs.collapse', function () {
        $("#mngFolders_toggle").addClass("sidebar-left-line");
    });

    $('#mngFoldersSubMenu').on('hidden.bs.collapse', function () {
        $("#mngFolders_toggle").removeClass("sidebar-left-line");
    });
});